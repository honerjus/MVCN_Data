clear
FD = dlmread(['FlowData.0001.txt']);

[row,col] = size(FD);
vel = FD(:,6);
min_vel = min(vel);
max_vel = max(vel);

a = log10(min_vel);
b = log10(max_vel);
c = linspace(a,b,6);

for i = 1:row
    x = [FD(i,1) FD(i,3)];
    y = [FD(i,2) FD(i,4)];
    for j = 1:5
        if (log10(FD(i,6)) > c(j) && log10(FD(i,6)) <= c(j+1))
            LT = 0.25*j*j;
        end
    end
    plot(x,y,'LineWidth',LT,'color',[0 0.3 1]);
    hold on
end

axis square
xlabel('X (m)','FontName','Arial','FontSize',22);
ylabel('Y (m)','FontName','Arial','FontSize',22);
set(gca,'FontSize',16);