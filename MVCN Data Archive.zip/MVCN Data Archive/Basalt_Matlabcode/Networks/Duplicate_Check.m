%net=load('Network_Data.00200.txt');

net1=Net(:,1); wonder1=wonder(:,1);
net2=Net(:,2); wonder2=wonder(:,2);
net3=Net(:,3); wonder3=wonder(:,3);
net4=Net(:,4); wonder4=wonder(:,4);

TNet=[net1 net2];
T2Net=[net3 net4];
NetT=[TNet;T2Net];
Twonder=[wonder1 wonder2];
T2wonder=[wonder3 wonder4];
wonderT=[Twonder; T2wonder];


%X1Net=unique(TNet,'rows');
%X2Net=unique(T2Net,'rows');
DFNNet=unique(NetT,'rows');
%X1wonder=unique(Twonder,"rows");
%X2wonder=unique(T2wonder,"rows");
DFNwonder=unique(wonderT,"rows");

%XY1Net=length(X1Net);
%XY2Net=length(X2Net);
XYTOTNet=length(DFNNet)
OriNet=length(Net)
%XY1wonder=length(X1wonder);
%XY2wonder=length(X2wonder);
XYTOTwonder=length(DFNwonder)
Oriwonder=length(wonder)
