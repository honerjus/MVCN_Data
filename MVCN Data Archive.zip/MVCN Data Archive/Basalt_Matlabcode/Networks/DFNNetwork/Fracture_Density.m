clear,close,clc

L=250; %Domain length of the networks
First=601; %First Network
Last=700; %Last Network
S=5; %Scalar for Mega-Columns
R=2.5; %Radius of normal Columns

Ensamble=0;
for n=First:Last %Identifies Individual Networks
    if n<=9
        net=load(sprintf('Network_Data.000%d.txt',n));

    elseif 9<n&n<100
        net=load(sprintf('Network_Data.00%d.txt',n));

    else n<=100
        net=load(sprintf('Network_Data.0%d.txt',n));

    end 
    %Seperates Matrix into usable values
    l=length(net);
    X1=net(:,1);
    X2=net(:,3);
    Y1=net(:,2);
    Y2=net(:,4);
    Fracture2=0;
    for w=1:(l-1) %Determines Fracture Density of network and saves variable
        fracturel=sqrt((X1(w,1)-X2(w,1))^2+(Y1(w,1)-Y2(w,1))^2);
        Fracture2=Fracture2+fracturel;
    end
    FracturePer=(Fracture2/250)*100;
    Ensamble=FracturePer+Ensamble; 
end

EnsFracPer=Ensamble/((Last-First)+1) %Calculates the average fracture density of all the networks
EstFracPer=(1/4)*EnsFracPer









