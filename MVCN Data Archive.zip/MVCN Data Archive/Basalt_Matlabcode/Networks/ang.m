function a=ang(x,y)

a=acos(sum(x.*y) / (norm(x)*norm(y)));
