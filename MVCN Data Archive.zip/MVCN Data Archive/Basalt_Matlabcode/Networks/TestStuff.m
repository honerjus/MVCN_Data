clear, close all, clc

A(1,:)=[20.6056 -1.0771];
A(2,:)=[14.9819 6.3359];
A(3,:)=[8.9629 0.3363];
A(4,:)=[11.3049 -2.9130];
A(5,:)=[17.8631 -4.4861];
A(6,:)=[20.6492 -1.5729];
A(7,:)=[20.6644 -1.0771];

figure,plot(A(:,1),A(:,2))

%%%The C value in the voronoin function identifies the Junction number that a node is located at in the voronoi diagram