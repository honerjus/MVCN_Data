function z = vmconst(xydata)

xpoints = xydata(:,1);
ypoints = xydata(:,2);
[v,c] = voronoin([xpoints,ypoints]);
v(1,:)=[-10*n,-10*n];

for pointnumber = 1:length(c)    
   vx1 = v(c{pointnumber},1)';
   vy1 = v(c{pointnumber},2)';
   k = length(vx1);
   
   %Calculate the parameters we need to update, record 'disorder', and
   %color the map.
   
   [cx,cy,carea] = centroid(vx1,vy1);

   vararea1(pointnumber) = abs(carea);
   varsides1(pointnumber) = k;                   
   x2 = [vx1,vx1];                  
   y2 = [vy1,vy1];                  
   anglesum = 0;                    
   for jj = 1:(k+1)                       
       a1 = [x2(jj)-x2(jj+1),y2(jj)-y2(jj+1)];                    
       a2 = -[x2(jj+1)-x2(jj+2),y2(jj+1)-y2(jj+2)];                     
       anglesum = anglesum + abs(ang(a1,a2)*180/pi-120);               
   end
   varangles1(pointnumber) = anglesum*2/k;
   
   if periodicextensionx(pointnumber) > (0)
        if periodicextensionx(pointnumber) <= (n)
            if periodicextensiony(pointnumber) <= (n)
                if periodicextensiony(pointnumber) > (0)
                    areacount = [areacount,abs(carea)];
                    sidecount = [sidecount,k];
                    x2 = [vx1,vx1];
                    y2 = [vy1,vy1];
                    for jj = 1:(k+1)
                        a1 = [x2(jj)-x2(jj+1),y2(jj)-y2(jj+1)];
                        a2 = -[x2(jj+1)-x2(jj+2),y2(jj+1)-y2(jj+2)];
                        anglecount = [anglecount,ang(a1,a2)*180/pi];
                        perangle = [perangle,0];
                        if anglecount(end) > 105
                            if anglecount(end) < 135
                                perangle(end) = 1;
                            end
                        end
                    end
                end
            end
        end
    end
   
   
   %Update the points
   
   pointcollectionx(pointnumber) =  cx;
   pointcollectiony(pointnumber) =  cy;
end;

ktally = 1;
    collectx = [];
    collecty = [];
    c1 = [];

%keep only valid points
%length(pointcollectionx)

for j = 1:length(pointcollectionx)
    if pointcollectionx(j) > 0
        if pointcollectionx(j) <= n
            if pointcollectiony(j) <= n
                if pointcollectiony(j) > 0
                    collectx(ktally) = pointcollectionx(j);
                    collecty(ktally) = pointcollectiony(j);
                    c1{ktally} = c{j};
                    ktally = ktally+1;
                    rcellcolor = [rcellcolor,abs(varsides1(j)-6)+abs((vararea1(j)-marea)/marea)+varangles1(j)/120];
                    
                end
            end
        end
    end
end


pointcollectionx = collectx;
pointcollectiony = collecty;

figure(1);

clf;
colormap = load('cmap1.txt');
caxis([0,1]);
axis([0,n,0,n]);
set(gca,'DataAspectRatio',[1 1 1]);

for i = 1:(length(c1)) 
    if all(c1{i}~=1)   
        patch(v(c1{i},1),v(c1{i},2),rcellcolor(i)); 
    end
end

drawnow;
end