function endpointss=network(D)
rng('shuffle')
%%% INPUT PARAMETERS %%%
Window=50.0000;
a=1.4;
lmin=1.5;
%D=1.6;
Nfrac=1400;
p=[0.25, 0.25;0.25,0.25];
rho=997.044; % in Kg/m3
gra= 9.8; % in m/s2
visco=0.0008937 ;% in Kg/s.m
%%% Multiplicative Cascade process %%%
p=proba(D);
p111=reshape(p,[2,2]);
pr=p111;
for k=1:7;
    n=0;
    for i=1:(2^k);
        for j=1:(2^k);
          tchil=proba(D);
          %ind=ceil(rand*size(tchil,1));
          %p112=tchil(ind,:); 
          p112=tchil(randperm(length(tchil)));
          p112=reshape(p112,[2,2]); 
          p2=p112;
          n=n+1;
          pr2=pr(i,j)*p2 ;
          OUT{i,j}=pr2;
        end
    end
pr=cell2mat(OUT);
save (['out',num2str(k)], 'OUT');
end
pr=cell2mat(OUT);

%Scaling the Probability map to domain size
X=0:(Window/length(pr)):(Window-(Window/length(pr)));
Y=0:(Window/length(pr)):(Window-(Window/length(pr)));
%figure, pcolor(X,Y,pr)
%colorbar
%figure,surf(X,Y,pr)

%Probability vector
prc=pr(:);% convert the probability density matrix (n x n) to a vector (1 x n^2)
cumP=cumsum(prc)/sum(prc);% Cumulative sum and normalization
%figure, cdfplot(prc)

%%% FRACTURE CENTERS %%%
% Inverse transform sampling
U= rand(Nfrac,1);
ind = zeros(size(U));
W=(discretize(U,cumP)+1);
matrix_size = size(pr); %%[m,n]
[Cx,Cy] = ind2sub(matrix_size,W);% This gives fracture center coordinates
Abalo_2=[Cx(:) Cy(:)];
Abalo_1=Abalo_2(all(~isnan(Abalo_2),2),:);
Cxx=Abalo_1(:,1);
Cyy=Abalo_1(:,2);

Cx_Cy_1=(Cxx*(Window/(length(pr)+1)));% Rescaling coordinates to window size
Cx_Cy_2=(Cyy*(Window/(length(pr)+1)));
Domain=(Window/(length(pr)));% cell size

Cx_Cy=[Cx_Cy_1(:) Cx_Cy_2(:)];

% Midpoints duplicates
for i=1:length(Abalo_1)
  probab=rand();
    if probab>0.5;
       n=1;
       m=-1;
    else if probab<0.5;
        n=-1;
        m=1;
       end
    end
 Variate_1=(rand()*((Domain/2)))*n;
 Variate_2=(rand()*((Domain/2)))*m;
 I(i)=(Cx_Cy(i,1)+Variate_1); 
 J(i)=(Cx_Cy(i,2)+Variate_2);
end

Nfract=length(Abalo_1);
%figure, scatter(J,I,'filled','k')
coord=[J(:), I(:)];
%writematrix(coord,'Coord_1.7_ok.csv')

% Verification of the output Fractal Dimension
Di=pdist(coord);
Dupli=sum(Di<0.01);% Verify if duplicates exist
min(Di);
max(Di);

% Number of pairs
Nt=Nfract;
r=min(Di):1:(max(Di)+1);
for i=1:length(r)
  Np(i) =  sum(Di<r(i));
  Cr=2*Np/(Nt*(Nt-1));
end
%figure, loglog(r, Cr,'-s')
%grid on
%writematrix([r(:),Cr(:)], 'FractalD_verif_1.5.csv')

% Fracture orientation
Or=rand(Nfract,1);
G1=Or(Or>0 & Or<=0.5);% subdivides orientation into sets
G2=Or(Or>0.5 & Or<=1);

Gr1=round(((circ_vmrnd(0.252,30,length(G1))*180)/3.14));%circ_vmrand uses kappa and mu to generate random variates
Gr2=round(((circ_vmrnd(1.871,30,length(G2))*180)/3.14));

SS1=circ_ang2rad(Gr1);
%figure, hist(SS1)
SS2=circ_ang2rad(Gr2);
%figure, hist(SS2)


Angle=[Gr1.', Gr2.']';
%writematrix(Angle,'Angle_check.csv')

% Fracture Length
xe = randp(Nfract,1,a,lmin);% randp assigns fracture length based on power law distribution
min(xe);
max(xe);
Le=xe/2;
I=I(:);
J=J(:);

%Fracture trace endpoints
for ii=1:Nfract
X1(ii)=J(ii)-(Le(ii)*cosd(Angle(ii)));
Y1(ii)=I(ii)-(Le(ii)*sind(Angle(ii)));
X2(ii)=J(ii)+(Le(ii)*cosd(Angle(ii)));
Y2(ii)=I(ii)+(Le(ii)*sind(Angle(ii)));
end

%%%%%%%%%%%%%%%%%%%%%%%%%%Censoring Longer fractures %%%%%%%%%%%%%%%%%%%
intermed=[X1(:),X2(:),Y1(:),Y2(:)]; %original
%Perform the truncations
square=[0.0000 0.0000; 0.0000 Window; Window 00.0000; Window Window];

Tau=intermed;
for i=1:Nfract
    
 v= reshape( intermed(i,:) , 2,[]);
 S=intersectionHull('vert',square,'vert',v);
 if isempty(S.vert)
  Tau(i,:)=NaN;
  
 else
     
  V=sortrows(S.vert);
  
  Tau(i,:)=abs([V(1,1) V(end,1) V(1,2) V(end,2)]); %truncated
 end
 
end
Tau;

endpoint=round([Tau(:,1),Tau(:,3),Tau(:,2),Tau(:,4)],4);
endpointt=endpoint(all(~isnan(endpoint),2),:);
endpoints=endpointt([1:Nfrac],:);
Longeur=sqrt((endpoints(:,3)-endpoints(:,1)).^2+(endpoints(:,4)-endpoints(:,2)).^2);% censored length

Trans_p=(1*1e-4)*ones(Nfrac,1);% Transmissivity based on the geometric mean of pumping test data
endpointss=[endpoints, Trans_p];

%writematrix(endpointss,'Network_Data.0001.txt','Delimiter','tab')
%%% Plotting the 2_D network %%%
A =round((endpoints(:,[1,3])),1); B =round((endpoints(:,[2,4])),1);
%figure, plot(A.',B.','LineWidth', 0.75)
grid on
axis square
axis([0 Window 0 Window])
title('Dc=1.6 ; alpha= 1.4, N=2100')

% Verification of fracture density (P21)
P21_ce=sum(Longeur(:))/(Window^2);
endpointss=[endpoints, Trans_p]




%end
