clear, close all
First=1;
Last=250;

normYmemory=[];

%PDF
for p=First:Last
    if p<=9
        Particle=load(sprintf('DFN_bcrv.000%d.txt',p));
    elseif 9<p&p<100
        Particle=load(sprintf('DFN_bcrv.00%d.txt',p));
    elseif p<=100
        Particle=load(sprintf('DFN_bcrv.0%d.txt',p));
    end

    P=Particle(:,7);
    MaxP=max(P);

    X=Particle(:,1); %Gets the time values
    Time=X/86400; %Converts to days
    Y=Particle(:,4); %particles through bottom face
    NormY=Y/MaxP;

    normYmemory(:,p)=NormY;

    plot(Time,NormY)
    hold on
    %color grey

end

normY=mean(normYmemory,2);
plot(Time,normY)
hold off

clear normYmemory
normYmemory=[];
figure,
 %CDF
 for p=First:Last
     if p<=9
         Particle=load(sprintf('DFN_bcrv.000%d.txt',p));
     elseif 9<p&p<100
         Particle=load(sprintf('DFN_bcrv.00%d.txt',p));
     elseif p<=100
         Particle=load(sprintf('DFN_bcrv.0%d.txt',p));
     end
 
     X=Particle(:,1); %Gets the time values
     Time=X/86400; %Converts to days
     Y1=Particle(:,7); %Total particles in the system
     NormY1=Y1/MaxP;
     plot(Time,NormY1)
     hold on
 end
 
 hold off