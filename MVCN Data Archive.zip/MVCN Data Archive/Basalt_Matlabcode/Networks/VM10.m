function zz = VM10(r1,iter_max,ntimes,movname)

% A program to impliment the Budkewitsch-Robin theory of quasihexagonal crack formation.
% Input parameters		n = axis length = 100 (now fixed)
%									r1 = radius of circles used during random close packing.
%									iter_max = number of iterations used in placing random points.
%									ntimes = number of iterations of
%									voronoi/centroid updating.

% Setup variables
tic;
mov = avifile(movname);
figure(1);

vararea = [];
varsides = [];
varangles = [];
perangles = [];
n = 100;

% Step 1: Construct a set of randomly close packed points(circles).  
%			 	Periodic boundary conditions are used.
 
pointcollectionx = ((n-1)*rand)+1;
pointcollectiony = ((n-1)*rand)+1;
pointnumber = 0;

for k = 1:iter_max
   testposit = [((n-1)*rand)+1,((n-1)*rand)+1];
      if min((testposit(1)-pointcollectionx').^2+(testposit(2)-pointcollectiony').^2) > r1^2
      pointnumber = pointnumber + 1;
      pointcollectionx(pointnumber) = testposit(1);
      pointcollectiony(pointnumber) = testposit(2);
   end
end

pointcollectionx

voronoi(pointcollectionx,pointcollectiony);
set(gca,'DataAspectRatio',[1 1 1]);
drawnow;

q = length(pointcollectionx)
marea = n^2/q;

toc;
tic;
%  Step 2: VOPOUNCE algorithm, calculate centroids of voronoi tesselation,
%  and use as new points for a voronoi tesselation.

for z = 1:ntimes

    vararea1 = [];
    varsides1 = [];
    varangles1 = [];
    perangles1 = [];
    rcellcolor = [];
    areacount = [];
    sidecount = [];
    anglecount = [];
    perangle = [];
    
    % Generate a periodic extension of the data set, and then trim it so
    % it's not too unwieldly.
    
    periodicextensionx = [pointcollectionx,pointcollectionx-n,pointcollectionx,pointcollectionx+n,pointcollectionx-n,pointcollectionx+n,pointcollectionx-n,pointcollectionx,pointcollectionx+n];
    periodicextensiony = [pointcollectiony,pointcollectiony+n,pointcollectiony+n,pointcollectiony+n,pointcollectiony,pointcollectiony,pointcollectiony-n,pointcollectiony-n,pointcollectiony-n];

    ktally = 1;
    collectx = [];
    collecty = [];

    for j = 1:length(periodicextensionx)
        if periodicextensionx(j) > (-3*r1)
            if periodicextensionx(j) <= (n+3*r1)
                if periodicextensiony(j) <= (n+3*r1)
                    if periodicextensiony(j) > (-3*r1)
                        collectx(ktally) = periodicextensionx(j);
                        collecty(ktally) = periodicextensiony(j);
                        ktally = ktally+1;
                    end
                end
            end
        end
    end

    periodicextensionx = collectx;
    periodicextensiony = collecty;



%Calculate the voronoi tesselation, and change the first point from
%infinity to something harmless.

[v,c] = voronoin([periodicextensionx;periodicextensiony]');
v(1,:)=[-10*n,-10*n];

for pointnumber = 1:length(c)    
   vx1 = v(c{pointnumber},1)';
   vy1 = v(c{pointnumber},2)';
   k = length(vx1);
   
   %Calculate the parameters we need to update, record 'disorder', and
   %color the map.
   
   [cx,cy,carea] = centroid(vx1,vy1);

   vararea1(pointnumber) = abs(carea);
   varsides1(pointnumber) = k;                   
   x2 = [vx1,vx1];                  
   y2 = [vy1,vy1];                  
   anglesum = 0;                    
   for jj = 1:(k+1)                       
       a1 = [x2(jj)-x2(jj+1),y2(jj)-y2(jj+1)];                    
       a2 = -[x2(jj+1)-x2(jj+2),y2(jj+1)-y2(jj+2)];                     
       anglesum = anglesum + abs(ang(a1,a2)*180/pi-120);               
   end
   varangles1(pointnumber) = anglesum*2/k;
   
   if periodicextensionx(pointnumber) > (0)
        if periodicextensionx(pointnumber) <= (n)
            if periodicextensiony(pointnumber) <= (n)
                if periodicextensiony(pointnumber) > (0)
                    areacount = [areacount,abs(carea)];
                    sidecount = [sidecount,k];
                    x2 = [vx1,vx1];
                    y2 = [vy1,vy1];
                    for jj = 1:(k+1)
                        a1 = [x2(jj)-x2(jj+1),y2(jj)-y2(jj+1)];
                        a2 = -[x2(jj+1)-x2(jj+2),y2(jj+1)-y2(jj+2)];
                        anglecount = [anglecount,ang(a1,a2)*180/pi];
                        perangle = [perangle,0];
                        if anglecount(end) > 105
                            if anglecount(end) < 135
                                perangle(end) = 1;
                            end
                        end
                    end
                end
            end
        end
    end
   
   
   %Update the points
   
   pointcollectionx(pointnumber) =  cx;
   pointcollectiony(pointnumber) =  cy;
end;

ktally = 1;
    collectx = [];
    collecty = [];
    c1 = [];

%keep only valid points
%length(pointcollectionx)

for j = 1:length(pointcollectionx)
    if pointcollectionx(j) > 0
        if pointcollectionx(j) <= n
            if pointcollectiony(j) <= n
                if pointcollectiony(j) > 0
                    collectx(ktally) = pointcollectionx(j);
                    collecty(ktally) = pointcollectiony(j);
                    c1{ktally} = c{j};
                    ktally = ktally+1;
                    rcellcolor = [rcellcolor,abs(varsides1(j)-6)+abs((vararea1(j)-marea)/marea)+varangles1(j)/120];
                    
                end
            end
        end
    end
end


pointcollectionx = collectx;
pointcollectiony = collecty;

% Produce colormap figures/movie

%figure(2);
vararea = [vararea,std(areacount)./mean(areacount)];
%plot(vararea,'.');

%figure(3);
varsides = [varsides,std(sidecount)];
%plot(varsides,'.');

%figure(4);
varangles = [varangles,std(anglecount)];
%plot(varangles,'.');

%figure(5)
perangles = [perangles,1-mean(perangle)];
%plot(perangles,'.');

figure(1);

clf;
%colormap = load('cmap1.txt');
caxis([0,1]);
axis([0,n,0,n]);
set(gca,'DataAspectRatio',[1 1 1]);

for i = 1:(length(c1)) 
    if all(c1{i}~=1)   
        patch(v(c1{i},1),v(c1{i},2),rcellcolor(i)); 
    end
end

drawnow;
F = getframe(gca);
mov = addframe(mov,F);
z
%[z,length(collectx)]
%zz = [z,100*vararea(end),100*varsides(end),varangles(end),100*(1-perangles(end))]
%z
end
%zz = [pointcollectionx,pointcollectiony]
mov = close(mov);


%figure(2);

%plot(vararea,'.');

%figure(3);
%plot(varsides,'.');

%figure(4);
%plot(varangles,'.');

%figure(5)
%plot(perangles,'.');

%toc
zz = [vararea;varsides;varangles;perangles];

dlmwrite('vm10outp', zz);
dlmwrite('vm10outpx', pointcollectionx);
dlmwrite('vm10outpy', pointcollectiony);

end





