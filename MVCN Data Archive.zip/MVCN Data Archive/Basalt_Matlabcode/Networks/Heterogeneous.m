clear all


% for N=100:250
%     if N<=9
%      %   Net=load(sprintf('Network_Data.000%d.txt',N));
%      %   writematrix(Net,sprintf('DFNNetwork/CNetwork_Data.000%d.txt',N),'Delimiter','tab')
%      %   Net2=load(sprintf('CNetwork_Data.000%d.txt',N));
%      %   Net=[Net(:,1) Net(:,2) Net(:,3) Net(:,4) Net2(:,5)];
%      %   writematrix(Net,sprintf('DFNNetwork/Network_Data.000%d.txt',N),'Delimiter','tab')
%     elseif 9<N<100
%         Net=load(sprintf('Network_Data.0%d.txt',N));
%         writematrix(Net,sprintf('DFNNetwork/CNetwork_Data.0%d.txt',N),'Delimiter','tab')
%         Net2=load(sprintf('CNetwork_Data.0%d.txt',N));
%         Net=[Net(:,1) Net(:,2) Net(:,3) Net(:,4) Net2(:,5)];
%         writematrix(Net,sprintf('DFNNetwork/Network_Data.0%d.txt',N),'Delimiter','tab')
%     else
%        % Net=load(sprintf('DFN_bcrv.0%d.txt',N));
%         %writematrix(Net,sprintf('DFNNetwork/Network_Data.0%d.txt',ib),'Delimiter','tab')
%     end
% end

for N=100:250
    if 99<N<251
        Net=load(sprintf('Network_Data.0%d.txt',N));
        W=length(Net);
        Net(W,5)=100;
        writematrix(Net,sprintf('DFNNetwork/Network_Data.0%d.txt',N),'Delimiter','tab')
    end
end