clear, close all
n=250; %Size of the domain in meters
r1=2.5; %Target radius for the polygons
iter_max=8000; %number of iterations used with placing random points
ntimes=1; %Number of fracture iterations/updates
I=0.0; %Immaturity of the network
Image=0; %If 0 code doesnt produce color movie: If 1 color movie is produced
N=0; %Use 0 if you don't want to have a node analysis: 1 If you want to record the number of nodes

for ib=1:1
   if ib<=9
       [Net,wonder,endpoint,CNodes]=VM12(n,r1,iter_max,ntimes);
       %writematrix(Net,sprintf('GNetwork/Fracture_Network.000%d.txt',ib),'Delimiter','tab')
       writematrix(Net,sprintf('DFNNetwork/Network_Data.000%d.txt',ib),'Delimiter','tab')
   elseif 9<ib&&ib<100
           [Net,wonder,endpoint]=VM12(n,r1,iter_max,ntimes);
          % writematrix(Net,sprintf('GNetwork/Fracture_Network.00%d.txt',ib),'Delimiter','tab')
           writematrix(Net,sprintf('DFNNetwork/Network_Data.00%d.txt',ib),'Delimiter','tab')
   elseif 100<ib 
           [Net,wonder,endpoint,CNodes]=VM12(n,r1,iter_max,ntimes);
          % writematrix(Net,sprintf('GNetwork/Fracture_Network.0%d.txt',ib),'Delimiter','tab')
           writematrix(Net,sprintf('DFNNetwork/Network_Data.0%d.txt',ib),'Delimiter','tab')
   end     
   
  %close all
end

if N==1
    net1=Net(:,1); %Breaks the network up into individual columns
    net2=Net(:,2);
    net3=Net(:,3);
    net4=Net(:,4);

    TNet=[net1 net2]; %Creates the nodes
    T2Net=[net3 net4];
    NetT=[TNet;T2Net];

    %X1Net=unique(TNet,'rows'); %Removes duplicate nodes
    %X2Net=unique(T2Net,'rows');
    DFNNet=unique(NetT,'rows');

    %XY1Net=length(X1Net); %length of the vector=number of individual nodes
    %XY2Net=length(X2Net);
    XYTOTNet=length(DFNNet)
    OriNet=2*length(Net);
end
