close all
clear all

square=[0 0; 0 2; 2 0; 2 2]
v=[0 1; 1 1]


S=intersectionHull('vert',square,'vert',v);
S.lcon
S.vert




 intermed=[X_11(:),X_22(:),Y_11(:),Y_22(:)]; %original
        %Perform the truncations
        square=[0.0000001 0.000001; 0.000001 n; n 0.00001; n n];

        Tau=intermed;
        for i=1:length(X_11)

            v= reshape( intermed(i,:) , 2,[]);
            S=intersectionHull('vert',square,'vert',v);
            if isempty(S.vert)
                Tau(i,:)=NaN;

            else

                V=sortrows(S.vert);

                Tau(i,:)=abs([V(1,1) V(end,1) V(1,2) V(end,2)]); %truncated
            end

        end
        Tau;

        %endpoint=round([Tau(:,1),Tau(:,3),Tau(:,2),Tau(:,4)],4);
        endpoint=[Tau(:,1),Tau(:,3),Tau(:,2),Tau(:,4)];
        endpointt=endpoint(all(~isnan(endpoint),2),:);


        %%%%%%%%% Removing duplicates - Added by Romeo %%%%%%%%%%%
        [C,ia,ib]=unique(endpointt,'rows','stable');
        i=true(size(endpointt,1),1);
        i(ia)=false;'Fracture_Image.%.fig';
        endpointt(i,:)=[];

        X_1=endpointt(:,1);
        X_2=endpointt(:,3);
        Y_1=endpointt(:,2);
        Y_2=endpointt(:,4);

        %for (i,i<size(endpointt),i++)
         %   for (j,j<size(endpointt)<j++)
         %       if endpointt(i)=matrix_2(j)
         %           duplicate=true
         %           if duplicate==true
          %              dont add
         %           end
         %       endwritematrix(wonder,sprintf('DFNNetwork/Network_Data.000%.d.txt',ib),'Delimiter','tab')
         %   end
       % end

        %for i=2:length(endpointt)
        %    if X_1(i)==X_1(i-1)
        %        X_1=0 %dont add row
        %    elseif Y_1(i)==Y_1(i-1)
        %        Y_1=0 %dont add row
        %end

        Trans_p=(1*1e-4)*ones(length(X_1),1);% Transmissivity based on the geometric mean of pumping test data
        
        w=[100 100 100 100 100]; %Added by Justin
        Output=round([X_1 Y_1 X_2 Y_2 Trans_p],6);
        Output=[Output;w]; %Also added by Justin
        %format long %Added to increase decimals
        super=(1*1e-4)*ones(length(wonder),1);
        wonder=[wonder super];
        wonder=[wonder;w];

        %Output=unique(Output,'rows');


        %$Output(Output == 0) = 0.00;
        %Output(Output == 100) = 100.00;


        %writematrix(Output,'Network_Data.0001.txt','Delimiter','tab')


        %drawnow;

        F = getframe(gca);
        %   mov = addframe(mov,F);
        zcount = 1+zcount*1.01

    end
    
    z;
    %[z,length(collectx)]
    %zz = [z,100*vararea(end),100*varsides(end),varangles(end),100*(1-perangles(end))]
    %z
end
%zz = [pointcollectionx,pointcollectiony]
%mov = close(mov);


%figure(2);

%plot(vararea,'.');

%figure(3);
%plot(varsides,'.');

%figure(4);
%plot(varangles,'.');

%figure(5)
%plot(perangles,'.');

toc
zz = [vararea;varsides;varangles;perangles];

%dlmwrite('vm10outp', zz);
%dlmwrite('vm10outpx', pointcollectionx);
%dlmwrite('vm10outpy', pointcollectiony);

fig = figure();
%X1=Xtt.';
%Y1=Ytt.';
%X2=Xtt.';
%Y2=Ytt.';


title('Network Plot');%Added by Romeo
%A =[XX1(:,1); XX1(:,2)]; B =[YY1(:,1); YY1(:,2)];
A =[X_1.'; X_2.']; B =[Y_1.'; Y_2.'];
plot(A,B,'LineWidth', 0.75,'Color','k')
xlim([0,n]); %both n were originally 100
ylim([0,n]);
end
