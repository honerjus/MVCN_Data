clear, close all
n=500;
r1=2.5;
iter_max=15000;
ntimes=10;
width=100;
height=100;
for ib=14:14
   if ib<=9
       Net=VM11_RectGrid(n,r1,iter_max,ntimes,width,height);
       writematrix(Net,sprintf('Network_Data.000%d.txt',ib),'Delimiter','tab')
   elseif 9<ib<100
           Net=VM11(n,r1,iter_max,ntimes);
           writematrix(Net,sprintf('Network_Data.00%d.txt',ib),'Delimiter','tab')
      
   else 
           Net=VM11(n,r1,iter_max,ntimes);
           writematrix(Net,sprintf('Network_Data.0%d.txt',ib),'Delimiter','tab')
     
   end          
           
end

net1=Net(:,1); %Breaks the network up into individual columns
net2=Net(:,2); 
net3=Net(:,3);
net4=Net(:,4);

TNet=[net1 net2]; %Creates the nodes
T2Net=[net3 net4];
NetT=[TNet;T2Net];

%X1Net=unique(TNet,'rows'); %Removes duplicate nodes
%X2Net=unique(T2Net,'rows');
DFNNet=unique(NetT,'rows');

%XY1Net=length(X1Net); %length of the vector=number of individual nodes
%XY2Net=length(X2Net);
XYTOTNet=length(DFNNet)
OriNet=2*length(Net)