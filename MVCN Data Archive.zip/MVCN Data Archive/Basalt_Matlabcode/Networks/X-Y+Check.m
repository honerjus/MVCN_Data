close, clc
net=load('Network_Data.0034')
