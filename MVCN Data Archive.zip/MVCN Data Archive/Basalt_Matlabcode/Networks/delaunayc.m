%DELAUNAYC Delaunay triangulation core routine.
%   TRI = DELAUNAYC(X,Y,...) is the same as DELUANAY except that no random
%   fuzz is added to the data before performing the triangulation.
%   DELAUNAYC will fail to produce the correct triangulation if X,Y
%   contains non-unique or collinear data points.
%
%   Based on sweepline Voronoi code by Steven Fortune.
%   
%   See also DELAUNAY.

%   Clay M. Thompson 7-8-95
%   Copyright (c) 1984-98 by The MathWorks, Inc.
%   $Revision: 1.1 $  $Date: 1998/06/08 20:37:17 $

%   The author of this software is Steven Fortune, AT&T Bell Laboratories.
%   Reference: Steve J. Fortune (1987) A Sweepline Algorithm for
%   Voronoi Diagrams, Algorithmica 2, 153-174.
%
%   Permission to use, copy, modify, and distribute this software for any
%   purpose without fee is hereby granted, provided that this entire notice
%   is included in all copies of any software which is or includes a copy
%   or modification of this software and in all copies of the supporting
%   documentation for such software.
%   THIS SOFTWARE IS BEING PROVIDED "AS IS", WITHOUT ANY EXPRESS OR IMPLIED
%   WARRANTY.  IN PARTICULAR, NEITHER THE AUTHORS NOR AT&T MAKE ANY
%   REPRESENTATION OR WARRANTY OF ANY KIND CONCERNING THE MERCHANTABILITY
%   OF THIS SOFTWARE OR ITS FITNESS FOR ANY PARTICULAR PURPOSE.
