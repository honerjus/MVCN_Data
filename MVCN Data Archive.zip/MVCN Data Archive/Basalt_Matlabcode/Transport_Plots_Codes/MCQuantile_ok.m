clear all
all_data=[];
 num=zeros(1,100);   
for ii=1:300
   Network_Data = sprintf('DFN_bcrv.0%d.txt',ii);
   if isfile(Network_Data);
    data=load(Network_Data);
    all_data = [all_data; data(:,7)]; 
    num(ii)=ii;
   end
end

num=nonzeros(num)
alldata=reshape(all_data,[15000,298]);% 207 needs to be updated to reflect the total number of files
Prim_list=alldata;
%Final list of good networks
z=any(alldata);
t=any(alldata~=10000);
p=(alldata(15000,:)>9900);
num_z=num(z);
num_t=num(t);
num_p=num(p);
zt=intersect(num_z,num_t);
Flist=intersect(zt, num_p);

% Removing columns
alldata=alldata(:,any(alldata));% remove column containing only zeros
alldata(:,all(alldata==10000))=[];% remove column containing only 10000
alldata(:,alldata(15000,:)<9900)=[];% remove column where the number of particles obtained is less than 99%
