'''  This script looks at the underlying distribution of particles traveltime  '''
clear all
data_16=(readmatrix('TravelTime_16.csv'))./3600;
data_18=(readmatrix('TravelTime_18.csv'))./3600;
data_20=(readmatrix('TravelTime_20.csv'))./3600;

%data_16=reshape(data_16,[1000000,1]);
%writematrix(data_16,'ArrivalTime_16.csv');
data_16_log=log(data_16);

%data_18=reshape(data_18,[1000000,1]);
%writematrix(data_18,'ArrivalTime_18.csv');
data_18_log=log(data_18);

%data_20=reshape(data_20,[1000000,1]);
%writematrix(data_20,'ArrivalTime_20.csv');
data_20_log=log(data_20)

writematrix([data_16(:,10) data_18(:,30) data_20(:,10)],'ProbAnalysis_t.csv');


%%%Normalized time
data_16_n=log((readmatrix('TravelTime_norm_16.csv'))./3600);
data_18_n=log((readmatrix('TravelTime_norm_18.csv'))./3600);
%data_20_n=(readmatrix('TravelTime_norm_20.csv'))./3600;

%%%%Plots
figure, histogram(data_16_log(:,10))
title('Dc-16')
figure, histogram(data_18_log(:,30))
title('Dc-18')
figure, histogram(data_20_log(:,10))
title('Dc-20')
