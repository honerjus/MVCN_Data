clear all
Window=50
all_Part=[]
%Network_Data_x = 'Par_StatX.050.txt';%sprintf('DFN_bcrv.0%d.txt',ii) 
%Network_Data_y = 'Par_StatY.050.txt';

Network_Data = 'Particles_last_location.010.txt'
%data_x=load(Network_Data_x);
%data_y=load(Network_Data_y);

data=load(Network_Data);
X_Start=data(:,1);
Y_Start=data(:,2);
X_End=data(:,3);
Y_End=data(:,4);
Final_time=data(:,5);

%$for i=1:10000;
    %X_Start(i)= min(data_x(:,i));
    %X_End(i)= max(data_x(:,i));
%end

%for i=1:10000;
    %Y_Start(i)= min(data_y(:,i));
    %Y_End(i)= max(data_y(:,i));
%end

A = [X_Start(:) X_End(:)]; B = [Y_Start(:) Y_End(:)];
x=[22.5, 27.5, 27.5, 22.5, 22.5];%Source release area
y=[44, 44, 49, 49, 44];
figure, plot(A.',B.','LineWidth', 0.25, 'Color', 'k'), hold on
plot(x, y, 'b-', 'LineWidth', 3);
xticks(0:10:50);
yticks(0:10:50);
xlabel('b')
grid on
axis square
axis([0 Window 0 Window])