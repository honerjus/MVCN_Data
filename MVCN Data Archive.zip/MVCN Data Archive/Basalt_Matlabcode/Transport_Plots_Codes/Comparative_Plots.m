clear all
data_16=readmatrix('Quantile_16_norm_s.csv');
data_16=data_16(:,[1:100]);
data_18=readmatrix('Quantile_18_norm_s.csv');
data_18=data_18(:,[1:100]);
data_20=readmatrix('Quantile_20_norm_s.csv');
data_20=data_20(:,[1:100]);

data_16_c=(readmatrix('Quantile_16_norm.csv'))./3600;
data_16_c=data_16_c(:,[1:100]);
data_18_c=(readmatrix('Quantile_18_norm.csv'))./3600;
data_18_c=data_18_c(:,[1:100]);
data_20_c=(readmatrix('Quantile_20_norm.csv'))./3600;
data_20_c=data_20_c(:,[1:100]);

%%%Average of the MC simulations
data_16_avg=median(data_16_c,2);
data_18_avg=median(data_18_c,2);
data_20_avg=median(data_20_c,2);

%%%
quant_16_1=data_16(1,:)./3600;
quant_16_5=data_16(2,:)./3600;
quant_16_16=data_16(3,:)./3600;
quant_16_84=data_16(4,:)./3600;
quant_16_95=data_16(5,:)./3600;
quant_16_99=data_16(6,:)./3600;

%%%
quant_18_1=data_18(1,:)./3600;
quant_18_5=data_18(2,:)./3600;
quant_18_16=data_18(3,:)./3600;
quant_18_84=data_18(4,:)./3600;
quant_18_95=data_18(5,:)./3600;
quant_18_99=data_18(6,:)./3600;

%%%
quant_20_1=data_20(1,:)./3600;
quant_20_5=data_20(2,:)./3600;
quant_20_16=data_20(3,:)./3600;
quant_20_84=data_20(4,:)./3600;
quant_20_95=data_20(5,:)./3600;
quant_20_99=data_20(6,:)./3600;

figure,
set(gcf,'color','w')
subplot('Position',[0.1 0.1 0.4 0.4])
boxplot([quant_16_1' quant_18_1' quant_20_1' quant_16_5' quant_18_5' quant_20_5' quant_16_95' quant_18_95' quant_20_95' quant_16_99' quant_18_99' quant_20_99'],'notch','on',...
    'labels',{'Dc-16-1%','Dc-18-1%','Dc-20-1%','Dc-16-5%','Dc-18-5%','Dc-20-5%','Dc-16-95%','Dc-18-95%','Dc-20-95%','Dc-16-99%','Dc-18-99%','Dc-20-99%'})
set(gca,'yscale','log')
ylim([1e1 1e5]);
ylabel('Quantiles')
xlabel('Time [hrs]')
title('T/d')

%ylim([0 6e8]);
%yticks(0:1e8:6e8);
title('')
%%%BC
increment=[0:0.01:1];
figure, plot(data_16_c(:,[1:100]),increment','Color',[0.8,0.8,0.8],'LineWidth',1); hold on
set(gca,'xscale','log')
plot(data_16_avg,increment','Color','k','LineWidth',2);
title('Dc-1.6-(t/d)')
xlim([1e1 1e5]);% For time not normalized
%xlim([1e1 1e6]);% For time/d
%xlim([1e-12 1e-8]);% For time/d
ylim([0 1])
ylabel('Quantiles')
xlabel('Time [hrs]')
hold off
