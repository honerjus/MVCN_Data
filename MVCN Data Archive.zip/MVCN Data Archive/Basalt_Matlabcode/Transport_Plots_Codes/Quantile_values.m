
''' This script plots a comparative boxplot of the three clustering case'''

clear all
data_16=readmatrix('Quantile_16_norm_s.csv')
data_16=data_16(:,[1:100]);
data_18=readmatrix('Quantile_18_norm_s.csv');% this file contains the 1%, 5% and 16% quantiles
data_18=data_18(:,[1:100]);
data_20=readmatrix('Quantile_20_norm_s.csv');
data_20=data_20(:,[1:100]);

%%%
quant_16_1=data_16(1,:)./3600;
quant_16_5=data_16(2,:)./3600;
quant_16_16=data_16(3,:)./3600;
quant_16_84=data_16(4,:)./3600;
quant_16_95=data_16(5,:)./3600;
quant_16_99=data_16(6,:)./3600;

%%%
quant_18_1=data_18(1,:)./3600;
quant_18_5=data_18(2,:)./3600;
quant_18_16=data_18(3,:)./3600;
quant_18_84=data_18(4,:)./3600;
quant_18_95=data_18(5,:)./3600;
quant_18_99=data_18(6,:)./3600;

%%%
quant_20_1=data_20(1,:)./3600;
quant_20_5=data_20(2,:)./3600;
quant_20_16=data_20(3,:)./3600;
quant_20_84=data_20(4,:)./3600;
quant_20_95=data_20(5,:)./3600;
quant_20_99=data_20(6,:)./3600;

%%% Data from Alpha=2.2
don=readmatrix('Quantiles_alpha_22.csv')
quant_16_22_1=don(:,1);
quant_18_22_1=don(:,2);
quant_20_22_1=don(:,3);

quant_16_22_5=don(:,4);
quant_18_22_5=don(:,5);
quant_20_22_5=don(:,6);

quant_16_22_95=don(:,7);
quant_18_22_95=don(:,8);
quant_20_22_95=don(:,9);

quant_16_22_99=don(:,10);
quant_18_22_99=don(:,11);
quant_20_22_99=don(:,12);

%figure, boxplot([quant_16_1' quant_18_1' quant_20_1' quant_16_5' quant_18_5' quant_20_5' quant_16_95' quant_18_95' quant_20_95' quant_16_99' quant_18_99' quant_20_99'],'Color',['r' 'b' 'k' 'r' 'b' 'k' 'r' 'b' 'k' 'r' 'b' 'k'],'notch','on',...
    %'labels',{'1','1','1','5','5','5','95','95','95','99','99','99'}), hold on
 %boxplot([quant_16_22_1 quant_18_22_1 quant_20_22_1 quant_16_22_5 quant_18_22_5 quant_20_22_5 quant_16_22_95 quant_18_22_95 quant_20_22_95 quant_16_22_99 quant_18_22_99 quant_20_22_99],'Color',['r' 'b' 'k' 'r' 'b' 'k' 'r' 'b' 'k' 'r' 'b' 'k'],'notch','on','BoxStyle','filled',...
    %'labels',{'1','1','1','5','5','5','95','95','95','99','99','99'}), hold off


figure, boxplot([quant_16_1' quant_18_1' quant_20_1' quant_16_5' quant_18_5' quant_20_5' quant_16_95' quant_18_95' quant_20_95' quant_16_99' quant_18_99' quant_20_99'],'Color',['r' 'b' 'k' 'r' 'b' 'k' 'r' 'b' 'k' 'r' 'b' 'k'],'notch','on',...
    'labels',{'1(2.2)','1(2.2)','1(2.2)','5(2.2)','5(2.2)','5(2.2)','95(2.2)','95(2.2)','95(2.2)','99(2.2)','99(2.2)','99(2.2)'}), hold on
 boxplot([quant_16_22_1 quant_18_22_1 quant_20_22_1 quant_16_22_5 quant_18_22_5 quant_20_22_5 quant_16_22_95 quant_18_22_95 quant_20_22_95 quant_16_22_99 quant_18_22_99 quant_20_22_99],'Color',['r' 'b' 'k' 'r' 'b' 'k' 'r' 'b' 'k' 'r' 'b' 'k'],'notch','on','BoxStyle','filled',...
    'labels',{'1(1.4)','1(1.4)','1(1.4)','5(1.4)','5(1.4)','5(1.4)','95(1.4)','95(1.4)','95(1.4)','99(1.4)','99(1.4)','99(1.4)'}), hold off

set(gca,'yscale','log')
ylim([1e1 1e5]);
xlabel('Quantiles')
ylabel('Time [hrs]')
title('T/d')
box_vars = findall(gca,'Tag','Box');
hLegend = legend(box_vars([3,2,4]), {'Dc=1.6','Dc=1.8','Dc=2.0'},'Location','northwest');
%ylim([0 6e8]);
%yticks(0:1e8:6e8);
title('')
%%%Scatter plots
liste_1=[quant_16_1' quant_18_1' quant_20_1'];
liste_5=[quant_16_5' quant_18_5' quant_20_5'];
liste_16=[quant_16_16' quant_18_16' quant_20_16'];
liste_84=[quant_16_84' quant_18_84' quant_20_84'];
liste_95=[quant_16_95' quant_18_95' quant_20_95'];
liste_99=[quant_16_99' quant_18_99' quant_20_99'];
for i=1:3
    %1%
    median_1(i)=median(liste_1(:,i));
    Quantile75_1(i)=quantile(liste_1(:,i),0.75);
    Quantile25_1(i)=quantile(liste_1(:,i),0.25);
    IQR_1(i)=quantile(liste_1(:,i),0.75)-quantile(liste_1(:,i),0.25);
   
    
    %5%
    median_5(i)=median(liste_5(:,i));
    Quantile75_5(i)=quantile(liste_5(:,i),0.75);
    Quantile25_5(i)=quantile(liste_5(:,i),0.25);
    IQR_5(i)=quantile(liste_5(:,i),0.75)-quantile(liste_5(:,i),0.25);
    
    %16%
    median_16(i)=median(liste_16(:,i));
    Quantile75_16(i)=quantile(liste_16(:,i),0.75);
    Quantile25_16(i)=quantile(liste_16(:,i),0.25);
    IQR_16(i)=quantile(liste_16(:,i),0.75)-quantile(liste_16(:,i),0.25);
    
    %84%
    median_84(i)=median(liste_84(:,i));
    Quantile75_84(i)=quantile(liste_84(:,i),0.75);
    Quantile25_84(i)=quantile(liste_84(:,i),0.25);
    IQR_84(i)=quantile(liste_84(:,i),0.75)-quantile(liste_84(:,i),0.25);
    
    %95%
    median_95(i)=median(liste_95(:,i));
    Quantile75_95(i)=quantile(liste_95(:,i),0.75);
    Quantile25_95(i)=quantile(liste_95(:,i),0.25);
    IQR_95(i)=quantile(liste_95(:,i),0.75)-quantile(liste_95(:,i),0.25);
    
    %99%
    median_99(i)=median(liste_99(:,i));
    Quantile75_99(i)=quantile(liste_99(:,i),0.75);
    Quantile25_99(i)=quantile(liste_99(:,i),0.25);
    IQR_99(i)=quantile(liste_99(:,i),0.75)-quantile(liste_99(:,i),0.25);
end
 Data_1=[median_1; Quantile75_1; Quantile25_1; IQR_1];
 writematrix(Data_1, 'SummaryStat_1%.csv')
 
 Data_5=[median_5; Quantile75_5; Quantile25_5; IQR_5];
 writematrix(Data_5, 'SummaryStat_5%.csv')
 
 Data_16=[median_16; Quantile75_16; Quantile25_16; IQR_16];
 writematrix(Data_16, 'SummaryStat_16%.csv')
 
 Data_84=[median_84; Quantile75_84; Quantile25_84; IQR_84];
 writematrix(Data_84, 'SummaryStat_84%.csv')
 
 Data_95=[median_95; Quantile75_95; Quantile25_95; IQR_95];
 writematrix(Data_95, 'SummaryStat_95%.csv')
 
 Data_99=[median_99; Quantile75_99; Quantile25_99; IQR_99];
 writematrix(Data_99, 'SummaryStat_99%.csv')
 
figure, scatter([1.6 1.8 2.0], IQR_1)