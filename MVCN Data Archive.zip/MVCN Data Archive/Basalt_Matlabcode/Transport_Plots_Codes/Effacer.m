clear all

A=[1    4    20
3    5    15
2    1    15
3    5    20
2    9    15
7    9    42];
U=1:1:6
V=[U'  A]
%[C,ia,ic]=unique(V(:,2))
for i=1:size(A,2)
    O(i)=unique(A(:,i));
    %Ct(:,:,i)=[C(:,i),ia(:,i)];
end
%Ct

for i=1:10
    Row(i)=min(find(X==Q(i)));
    Time(i)=Row(i)*43200;
end
for i=1:71
    for j=1:10
        C=Q2(i,:);
        B(:,:,i)=min(find(alldata_f(:,i)==Q2(j,i)));
    end
end
