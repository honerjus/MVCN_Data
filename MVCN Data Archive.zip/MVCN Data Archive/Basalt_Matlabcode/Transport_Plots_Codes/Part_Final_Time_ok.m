''' This code returns networks with 99% recovery and prepare the input files for Comparative_Plots, TravelTimePlots, and Quantile_values '''
clear all
all_data=[];
 %num=zeros(1,100);   
 Nfiles=197;
for ii=1:200
   Network_Data = sprintf('DFN_bcrv.0%d.txt',ii);
   if isfile(Network_Data);
    data=load(Network_Data);
    all_data = [all_data; data(:,7)]; 
    num(ii)=ii;
   end
end

num=nonzeros(num)
alldata=reshape(all_data,[15000,Nfiles]);% 207 needs to be updated to reflect the total number of files
Prim_list=alldata;
%Final list of good networks
z=any(alldata);
t=any(alldata~=10000);
p=(alldata(15000,:)>9900);
num_z=num(z);
num_t=num(t);
num_p=num(p);
zt=intersect(num_z,num_t);
Flist=intersect(zt, num_p);
% Removing columns
alldata=alldata(:,any(alldata));% remove column containing only zeros
alldata(:,all(alldata==10000))=[];% remove column containing only 10000
alldata(:,alldata(15000,:)<9900)=[];% remove column where the number of particles obtained is less than 99%

%%%% Getting time data
Part_Time_data = []; 
Part_X_Start = [];
Part_Y_Start = [];
Part_X_End = [];
Part_Y_End = [];
F_list=Flist';
for k=1:length(F_list)
   index=F_list(k);
   Part_Data = sprintf('Particles_last_location.0%d.txt',index);
   if isfile(Part_Data);
    Part_data=load(Part_Data);
    Part_Time_data = [Part_Time_data; Part_data(:,5)]; 
    Part_X_Start = [Part_X_Start; Part_data(:,1)];
    Part_Y_Start = [Part_Y_Start; Part_data(:,2)];
    Part_X_End = [Part_X_End; Part_data(:,3)];
    Part_Y_End = [Part_Y_End; Part_data(:,4)];
     
    
   end
end

%%%%% Reorganizing Data
Part_Dist = sqrt((Part_X_End-Part_X_Start).^2+(Part_Y_End-Part_Y_Start).^2);
%%%Normalizing Time
Part_Time_Norm=Part_Time_data./Part_Dist;
Part_vel=Part_Dist./Part_Time_data;
Part_TD=Part_Dist.*Part_Time_data;

Part_Time_data=reshape(Part_Time_data,[10000,length(F_list)]);% 207 needs to be updated to reflect the total number of fi
Part_vel=reshape(Part_vel,[10000,length(F_list)]);
Part_TD=reshape(Part_TD,[10000,length(F_list)]);
%%%
Time_data=Part_Time_data(:,[1:100]);
writematrix(Time_data, 'TravelTime_20.csv')%Input for the TravelTimePlots script

Part_Time_Norm=reshape(Part_Time_Norm,[10000,length(F_list)]);
%%%
Time_data_norm=Part_Time_Norm(:,[1:100]);
writematrix(Time_data_norm, 'TravelTime_norm_20_Alpha_14.csv')%Input for the TravelTimePlots script

Part_Time_data=Part_Time_data(:,[1:100]);
%Part_Time_Norm=Part_Time_Norm(:,[1:100]);

%%%% Plots
%%% Quantiles
increment=[0.01 0.05 0.16 0.84 0.95 0.99];
increment_c=[0:0.01:1];
Q1=quantile(Part_Time_Norm,increment);
Q1_c=quantile(Part_Time_Norm,increment_c);
Q2_c=quantile(Part_vel,increment_c);
Q3_c=quantile(Part_TD,increment_c);

writematrix(Q1_c, 'Quantile_20_norm.csv');% Input file for Comparative_Plots script
writematrix(Q1, 'Quantile_20_norm_s_v4.csv');% Input file for Quantile_values script(Boxplot)
%writematrix(Q3_c, 'Quantile_20_TD.csv');


Q1_mean=mean(Q1,2);
Q1_median=median(Q1,2);

figure, plot( increment_c',Q1_c,'o-','LineWidth',0.001)
%set(gca,'yscale','log')
ylim([0 6e8]);
yticks(0:1e8:6e8);
title('DC_20')
figure, plot( increment',Q1_mean,'o-','LineWidth',0.001)
ylim([0 7e7]);
yticks(0:1e7:7e7);
title('DC_20')

figure, boxplot(Q1')
set(gca,'yscale','log')
ylim([0 6e8]);
yticks(0:1e8:6e8);
title('DC_20')