clear all
all_data=[];
  
for ii=1:300
   Network_Data = sprintf('DFN_bcrv.0%d.txt',ii);
   if isfile(Network_Data);
    data=load(Network_Data);
    all_data = [all_data; data(:,7)]; 
    Time_incr=data(:,1);
   end
end
alldata=reshape(all_data,[15000,298]);% 207 needs to be updated to reflect the total number of files

% Removing columns
alldata=alldata(:,any(alldata));% remove column containing only zeros
alldata(:,all(alldata==10000))=[];% remove column containing only 10000
alldata(:,alldata(15000,:)<9900)=[];% remove column where the number of particles obtained is less than 99%

alldata(:,[3 13 14 18 25 32 34 38 39 40 47 54 55 65 72 77 82 92 98 104 112 130 146 156 163 168 171 188 189 193])=[];% remove files where the quantile is a decimal
alldata_f=alldata;
alldata_f(:,[25 85 104])=[];% remove files where quantile can't be found

%X=alldata_f(:,23);
increment=0.1:0.1:1;
%Q=quantile(X,increment);
Q1=quantile(alldata_f,increment);
Q1_time=Q1.*43200;
Q2=Q1';
for k=1:100
    for i=1:10
        X=alldata_f(:,k);
        Q=Q2(k,:);
        Row(k,i)=min(find(X==Q(i)));
        Time(k,i)=Row(k,i)*12;
    end
end
Conc=alldata_f./10000;% Normalizes by the total number of particles
ConcMean=mean(Conc,2); % Returns the mean of all simulations

figure, plot( increment',Q1_time,'o-','LineWidth',0.001)
%figure, plot(Time,increment,'o-')
%figure, plot(Time_incr,alldata_f(:,:),'o-')

figure, plot(Time_incr,Conc(:,:),'o-','LineWidth',0.01)%, hold on
%plot(Time_incr,ConcMean(:,:),'+-','Color','k'), hold off

%figure, boxplot(alldata_f)
%figure, boxplot(Q1)
figure, boxplot(Time)
