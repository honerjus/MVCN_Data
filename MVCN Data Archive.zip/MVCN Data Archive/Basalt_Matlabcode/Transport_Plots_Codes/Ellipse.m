clear all
xCenter = 0;
yCenter = 0;
%
xCenter_2= 0;
yCenter_2= 0;
%
xCenter_3 = 0;
yCenter_3 = 0;
%DC=1.6
xRadius = 1.7;
yRadius = 2.3;
%DC=1.8
xRadius_2 = 1.4;
yRadius_2 = 1.9;
%DC=2.0
xRadius_3 = 1.0;
yRadius_3 = 1.0;

theta = 0 : 0.01 : 2*pi;
x = xRadius * cos(theta) + xCenter;
y = yRadius * sin(theta) + yCenter;

x2 = xRadius_2 * cos(theta) + xCenter_2;
y2 = yRadius_2 * sin(theta) + yCenter_2;

x3 = xRadius_3 * cos(theta) + xCenter_3;
y3= yRadius_3 * sin(theta) + yCenter_3;

plot(x, y, 'LineWidth', 3); hold on
plot(x2, y2, 'LineWidth', 3)
plot(x3, y3, 'LineWidth', 3,'Color', 'k')
legend('Dc=1.6', 'Dc=1.8', 'Dc=2.0')
axis square;
xlim([-3 3]);
ylim([-3 3]);
grid on; hold off

%%% Performance plots
x=categorical({'Dc=1.6', 'Dc=1.8', 'Dc=2.0'});
y14=[60 81 96];
y22=[23 46 66];

figure
b1=bar(x,y14)
hold on
b2=bar(x,y22,'Barwidth', 0.5), 

ylabel('% Successful Networks')
xlabel('Correlation Dimension')
legend([b1 b2], 'Alpha=1.4', 'Alpha=2.2', 'location','northwest')

%%% Plots quantile comparison
xq=categorical({'Q95','Q99'});
y16=[86 124];
y18=[77 107];
y20=[67 96];
figure
b11=bar(xq,y16);
hold on
b22=bar(xq,y18,'Barwidth', 0.6);
b33=bar(xq,y20,'Barwidth', 0.4);


ylabel('Median of normalized time')
xlabel('Quantile')
legend([b11 b22 b33], 'Dc=1.6', 'Dc=1.8', 'Dc=2.0', 'location','northwest')
ylim([0 450]);