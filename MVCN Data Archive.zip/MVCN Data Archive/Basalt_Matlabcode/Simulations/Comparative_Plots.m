clear all
data_16=readmatrix('Quantile_PolyG_norm_s.csv');
data_16_c=(readmatrix('Quantile_PolyG_norm.csv'))./3600;


%%%Average of the MC simulations
data_16_avg=median(data_16_c,2);


%%%
quant_16_1=data_16(1,:)./3600;
quant_16_5=data_16(2,:)./3600;
quant_16_16=data_16(3,:)./3600;
quant_16_84=data_16(4,:)./3600;
quant_16_95=data_16(5,:)./3600;
quant_16_99=data_16(6,:)./3600;

%%%BC
increment=[0:0.01:1];
figure,
subplot('Position',[0.1 0.1 0.3 0.3])
plot(data_16_c(:,:),increment','Color',[0.8,0.8,0.8],'LineWidth',1); hold on
set(gca,'xscale','log')
%plot(data_16_avg,increment','Color','k','LineWidth',2);
%title('Dc-1.6-(t/d)')
%xlim([1e1 1e5]);% For time not normalized
xlim([1e2 1e5]);% For time/d
%xlim([1e-12 1e-8]);% For time/d
ylim([0 1])
ylabel('Quantiles')
%xlabel('Time [hrs]')
xlabel('Normalized Time')
hold off

