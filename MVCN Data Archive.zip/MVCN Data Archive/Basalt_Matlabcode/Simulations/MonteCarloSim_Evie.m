clear all
for k=1:10;
    if k<10
        Network_Data = sprintf('Network_Data.000%d.txt',k)
        myDon=load(Network_Data);
        writematrix(myDon,sprintf('Network_Data.000%d.txt',1),'Delimiter','tab')
        
        Data_and_OutputOptions=fopen('Data_and_OutputOptions.txt','r')
        executable=system('C:\Users\rnz4569\Desktop\01.28.2021\Evie_Simulations\Simulations\DFNSimulator.exe')%This
        %line is correct --Romeo       
        %Dossier=
        %'C:\Users\rnz4569\Desktop\Evie\Evie_Simulations\Simulations';%
        %This line shoud be 
        Dossier='C:\Users\rnz4569\Desktop\01.28.2021\Evie_Simulations\Simulations'       
        if isfile('NoConDFN.0001.txt')
                
            %Renaming Fracture file
            FractureOld='Fractures.0001.bln'
            FractureNew=sprintf('Fractures.0%d.bln',k)
            movefile(fullfile(Dossier,FractureOld),fullfile(Dossier,FractureNew))
        
            %Renaming Segments file
            SegmentsOld='Segments.0001.bln'
            SegmentsNew=sprintf('Segments.0%d.bln',k)
            movefile(fullfile(Dossier,SegmentsOld),fullfile(Dossier,SegmentsNew))
            
            %Renaming Convergence file
            NCOld='NoConDFN.0001.txt'
            NCNew=sprintf('NoConDFN.0%d.txt',k)
            movefile(fullfile(Dossier,NCOld),fullfile(Dossier,NCNew))
                      
        elseif isfile('Fractures.0001.bln') && isfile('Segments.0001.bln')&& isfile('Backbone.0001.bln') && isfile('dfnhead.0001.txt') && isfile('FlowData.0001.txt') && isfile('DFN_flow.0001.txt') && isfile('DFN_bcrv.0001.txt') && isfile('Particles_last_location.0001.txt')
            %Renaming Fracture file
            FractureOld='Fractures.0001.bln'
            FractureNew=sprintf('Fractures.0%d.bln',k)
            movefile(fullfile(Dossier,FractureOld),fullfile(Dossier,FractureNew))

            %Renaming Segments file
            SegmentsOld='Segments.0001.bln'
            SegmentsNew=sprintf('Segments.0%d.bln',k)
            movefile(fullfile(Dossier,SegmentsOld),fullfile(Dossier,SegmentsNew))

            %Renaming Backbone file
            BackboneOld='Backbone.0001.bln'
            BackboneNew=sprintf('Backbone.0%d.bln',k)
            movefile(fullfile(Dossier,BackboneOld),fullfile(Dossier,BackboneNew))

            %Renaming Head file
            DFNHeadOld='dfnhead.0001.txt'
            DFNHeadNew=sprintf('dfnhead.0%d.txt',k)
            movefile(fullfile(Dossier,DFNHeadOld),fullfile(Dossier, DFNHeadNew))

            %Renaming FlowData file
            FlowDataOld='FlowData.0001.txt'
            FlowDataNew=sprintf('FlowData.0%d.txt',k)
            movefile(fullfile(Dossier,FlowDataOld),fullfile(Dossier, FlowDataNew))

            %Renaming Flow file
            DFNFlowOld='DFN_flow.0001.txt'
            DFNFlowNew=sprintf('DFN_flow.0%d.txt',k)
            movefile(fullfile(Dossier,DFNFlowOld),fullfile(Dossier, DFNFlowNew))

            %Renaming BC file
            DFNBCOld='DFN_bcrv.0001.txt'
            DFNBCNew=sprintf('DFN_bcrv.0%d.txt',k)
            movefile(fullfile(Dossier,DFNBCOld),fullfile(Dossier, DFNBCNew))

            %Renaming Particle file
            ParOld='Particles_last_location.0001.txt'
            ParNew=sprintf('Particles_last_location.0%d.txt',k)
            movefile(fullfile(Dossier,ParOld),fullfile(Dossier, ParNew))

            
        else
            disp('Some files are missing')
        end
        
    else
        Network_Data = sprintf('Network_Data.00%d.txt',k)
        myDon=load(Network_Data);
        writematrix(myDon,sprintf('Network_Data.000%d.txt',1),'Delimiter','tab')
        
        Data_and_OutputOptions=fopen('Data_and_OutputOptions.txt','r')
        %executable=system('C:\Users\rnz4569\Desktop\Evie\Network_Gen_Output\E0.2\E0.2,H0.8\50x50\DFNSimulator.exe')
        executable=system('C:\Users\rnz4569\Desktop\01.28.2021\Evie_Simulations\Simulations\DFNSimulator.exe')
        
        %Dossier= 'C:\Users\rnz4569\Desktop\Evie\Network_Gen_Output\E0.2\E0.2,H0.8\50x50';
        Dossier='C:\Users\rnz4569\Desktop\01.28.2021\Evie_Simulations\Simulations'
        if isfile('NoConDFN.0001.txt') 
            
            %Renaming Fracture file
            FractureOld='Fractures.0001.bln'
            FractureNew=sprintf('Fractures.0%d.bln',k)
            movefile(fullfile(Dossier,FractureOld),fullfile(Dossier,FractureNew))
        
            %Renaming Segments file
            SegmentsOld='Segments.0001.bln'
            SegmentsNew=sprintf('Segments.0%d.bln',k)
            movefile(fullfile(Dossier,SegmentsOld),fullfile(Dossier,SegmentsNew))
            
            %Renaming Convergence file
            NCOld='NoConDFN.0001.txt'
            NCNew=sprintf('NoConDFN.0%d.txt',k)
            movefile(fullfile(Dossier,NCOld),fullfile(Dossier,NCNew))
           
           
        elseif isfile('Fractures.0001.bln') && isfile('Segments.0001.bln')&& isfile('Backbone.0001.bln') && isfile('dfnhead.0001.txt') && isfile('FlowData.0001.txt') && isfile('DFN_flow.0001.txt') && isfile('DFN_bcrv.0001.txt') && isfile('Particles_last_location.0001.txt') 
            %Renaming Fracture file
            FractureOld='Fractures.0001.bln'
            FractureNew=sprintf('Fractures.0%d.bln',k)
            movefile(fullfile(Dossier,FractureOld),fullfile(Dossier,FractureNew))

            %Renaming Segments file
            SegmentsOld='Segments.0001.bln'
            SegmentsNew=sprintf('Segments.0%d.bln',k)
            movefile(fullfile(Dossier,SegmentsOld),fullfile(Dossier,SegmentsNew))

            %Renaming Backbone file
            BackboneOld='Backbone.0001.bln'
            BackboneNew=sprintf('Backbone.0%d.bln',k)
            movefile(fullfile(Dossier,BackboneOld),fullfile(Dossier,BackboneNew))

            %Renaming Head file
            DFNHeadOld='dfnhead.0001.txt'
            DFNHeadNew=sprintf('dfnhead.0%d.txt',k)
            movefile(fullfile(Dossier,DFNHeadOld),fullfile(Dossier, DFNHeadNew))

            %Renaming FlowData file
            FlowDataOld='FlowData.0001.txt'
            FlowDataNew=sprintf('FlowData.0%d.txt',k)
            movefile(fullfile(Dossier,FlowDataOld),fullfile(Dossier, FlowDataNew))

            %Renaming Flow file
            DFNFlowOld='DFN_flow.0001.txt'
            DFNFlowNew=sprintf('DFN_flow.0%d.txt',k)
            movefile(fullfile(Dossier,DFNFlowOld),fullfile(Dossier, DFNFlowNew))

            %Renaming BC file
            DFNBCOld='DFN_bcrv.0001.txt'
            DFNBCNew=sprintf('DFN_bcrv.0%d.txt',k)
            movefile(fullfile(Dossier,DFNBCOld),fullfile(Dossier, DFNBCNew))

            %Renaming Particle file
            ParOld='Particles_last_location.0001.txt'
            ParNew=sprintf('Particles_last_location.0%d.txt',k)
            movefile(fullfile(Dossier,ParOld),fullfile(Dossier, ParNew))

        else
            disp('Some files are missing')
        end
        
    end
       
end