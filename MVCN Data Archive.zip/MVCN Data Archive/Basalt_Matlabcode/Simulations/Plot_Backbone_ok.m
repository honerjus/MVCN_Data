clear all
Window=1000
%endpoints1=readmatrix();
%X1= endpoints(:,1);
%Y1= endpoints(:,2);
%X2= endpoints(:,3);
%Y2= endpoints(:,4);

fl=readmatrix('Backbone.0001.csv')
fl;
m=length(fl)
Start_X=fl(1:2:(m-1),1)
Finish_X=fl(1:2:(m-1),2)
Start_Y=fl(2:2:m,1)
Finish_Y=fl(2:2:m,2)






%A = [X1(:) X2(:)]; B = [Y1(:) Y2(:)];
Ab = [Start_X(:) Start_Y(:)].'; Bb =[Finish_X(:)  Finish_Y(:)].';
x=[450, 550, 550, 450, 450];%Source release area
y=[880, 880, 980, 980, 880];

%subplot(1,2,1)
%set(gcf,'color','w')
%hold on
%subplot('Position',[0.2 0.2 0.2 0.2])
%plot(A.',B.','LineWidth', 0.25, 'Color', 'k')
%xticks(0:10:40);
%yticks(0:10:40);
%xlabel('a')
%grid on
%axis square
%axis([0 Window 0 Window])
%subplot(1,2,2)
%subplot('Position',[0.40 0.2 0.2 0.2])

figure, plot(Ab,Bb,'LineWidth', 0.25, 'Color', 'k'), hold on
plot(x, y, 'r-', 'LineWidth', 2)
xticks(0:100:1000);
yticks(0:100:1000);
%xlabel('b')
grid on
axis square
axis([0 Window 0 Window])
%hold off