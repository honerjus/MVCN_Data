% Hydraulic gradient in the y direction
clear all
all_data=[]
nfiles=10
for i=1:nfiles
    Network = sprintf('DFN_flow.0%d.txt',i)
    fid=fopen(Network);
    Flow=textscan(fid, '%s %s %s %s %s %f64');
    fclose(fid);
    FlowComp=cell2mat(Flow(6))     
    all_data = [all_data; FlowComp(:)]; 
end
alldata=all_data(~isnan(all_data))
%Direction=["Top Face"; "Right Face"; "Bottom Face"; "Left Face"]
%allData=[Direction(:); alldata(:)]
FlowVal=reshape(alldata,[4,nfiles])

% Equivalent Tensor
HG=0.25 % Hydraulic gradient

%K_T=FlowVal(1,:)/HG % Top face
K_xy=abs(FlowVal(2,:)/HG)% Right face
K_yy=abs(FlowVal(3,:)/HG)% Bottom face
%K_L=FlowVal(4,:)/HG % Left face


Kt_mean=[geomean(K_xy),geomean(K_yy)]

%Kt_prin=eig(Kt_mean,'matrix')
%K_equival=sqrt((Kt_prin(1,1))^2+(Kt_prin(2,2))^2)

