clear, clc
First=1;   Last=250;
MC=1; %0=no unique feature: 1=unique feature present
L=250; %Total length of the entire domain

for p=First:Last
    if p<=9
        particle=load(sprintf('Particles_last_location.000%d.txt',p));
    elseif 9<p&&p<100
        particle=load(sprintf('Particles_last_location.00%d.txt',p));
    elseif p>=100
        particle=load(sprintf('Particles_last_location.0%d.txt',p));
    end

    if MC==1
        if p<=9
            pnet=load(sprintf('Primordial_Network.000%d.txt',p));
        elseif 9<p&&p<100
            pnet=load(sprintf('Primordial_Network.00%d.txt',p));
        elseif p>=100
            pnet=load(sprintf('Primordial_Network.0%d.txt',p));
        end

        P1=[pnet(:,1) pnet(:,2)];
        P2=[pnet(:,3) pnet(:,4)];
        nodes=[P1;P2];
        Nodes=unique(nodes,'rows');
    end

    INodes=[particle(:,1) particle(:,2);];
    Unique_INodes=unique(INodes,'rows');

    Unique_input_per=[];
    P_Node_Input=[];
    Counter=0;
    for i=1:length(Unique_INodes)
        for j=1:length(INodes)
            if Unique_INodes(i,1)==INodes(j,1) && Unique_INodes(i,2)==INodes(j,2)
                Counter=Counter+1;
            end
        end

        if i==1
            Unique_input_per(i,1)=(Counter/(length(INodes)))*100;
            C1=Counter;
        else
            Counter=Counter-C1;
            Unique_input_per(i,1)=(Counter/(length(INodes)))*100;
            Counter=C1;
        end

        if i==1
            MCCounter=0;
        end

        if MC==1
            for k=1:length(Nodes)
                if Unique_INodes(i,1)==Nodes(k,1) && Unique_INodes(i,2)==Nodes(k,2)
                    dist=0;     MC_Node=0;
                    Node_Input=[Unique_INodes(i,1) Unique_INodes(i,2) dist];
                    P_Node_Input=[P_Node_Input;Node_Input];
                    MCRelease(i,1)=Unique_input_per(i,1);
                    MCCounter=MCCounter+1;
                    break
                else
                    MC_Node=1;
                end
            end

            currentdist=(L*2);
            if MC_Node==1
                for k=1:length(Nodes)
                    dist=sqrt((Unique_INodes(i,1)-Nodes(k,1))^2+(Unique_INodes(i,2)-Nodes(k,2))^2);
                    if dist<currentdist
                        currentdist=dist;
                    end
                end
                Node_Input=[Unique_INodes(i,1) Unique_INodes(i,2) currentdist];
                P_Node_Input=[P_Node_Input;Node_Input];
            end
        end

        if Unique_INodes(i,2)>(L-2)
            disp('Edge node')
        end
    end

    SUMMCNodes=sum(MCRelease);
    clear MCRelease
    SINNodes(p,1)=SUMMCNodes;
    Max(p,1)=max(Unique_input_per);
    Min(p,1)=min(Unique_input_per);
    NodeNum(p,1)=length(Unique_INodes);
    Range=[Max Min NodeNum];
    
    if MC==1
        Dist=P_Node_Input(:,3);
        Max_Dist(p,1)=max(Dist);
        Min_Dist(p,1)=min(Dist);
        Mean_Dist(p,1)=mean(Dist);
        Distance_Analysis=[Max_Dist Min_Dist Mean_Dist];

        Value=0;
        for z=1:length(Dist)
            if Dist(z,1)==0
                Value=Value+1;
            else
                Value=Value;
            end
        end
        MC_Release_Node(p,1)=Value;
    end
end

Average_Input_Nodes=mean(Range(:,3))
if MC==1
    Average_Mean_Dist=mean(Distance_Analysis(:,3))
    Average_Max_Dist=mean(Distance_Analysis(:,1))
    Mega_Column_Release_Per=(mean(MC_Release_Node(:,1))/Average_Input_Nodes)*100
    Average_Mega_Column_In_Per=mean(SINNodes)
end