close all, clear, clc
N=1;

for n=N:N %Identifies Individual Networks
    if n<=9
        net=load(sprintf('Network_Data.000%d.txt',n));

    elseif 9<n&&n<100
        net=load(sprintf('Network_Data.00%d.txt',n));

    elseif n>=100
        net=load(sprintf('Network_Data.0%d.txt',n));
    end

    if n<=9        
        Pnet=load(sprintf('Primordial_Network.000%d.txt',n));
    elseif 9<n&n<100
        Pnet=load(sprintf('Primordial_Network.00%d.txt',n));
    elseif n>=100
        Pnet=load(sprintf('Primordial_Network.0%d.txt',n));
    end
end
    

l=length(net);
X1=net(1:(l-1),1);
X2=net(1:(l-1),3);
Y1=net(1:(l-1),2);
Y2=net(1:(l-1),4);

% %Use To view Original Network
% A=[X1'; X2']; B=[Y1'; Y2'];
% figure,plot(A,B,'LineWidth', 0.75,'Color','k')
% hold on
% axis('equal')
% hold off

% plot for mega columns
l=length(net);
A=[X1'; X2']; B=[Y1'; Y2'];
hold on
plot(A,B,'LineWidth', 0.75,'Color','k')
pl=length(Pnet);
pX1=Pnet(:,1);
pX2=Pnet(:,3);
pY1=Pnet(:,2);
pY2=Pnet(:,4);
Fracture4=0;
l=length(Pnet);
C=[pX1'; pX2']; D=[pY1'; pY2'];
plot(C,D,'LineWidth', 2,'Color','k')
axis equal
hold off