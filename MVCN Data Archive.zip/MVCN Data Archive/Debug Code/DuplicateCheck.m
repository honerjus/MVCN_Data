Net=load('Network_Data.0005.txt');

net1=Net(:,1); %Breaks the network up into indicidual columns
net2=Net(:,2); 
net3=Net(:,3);
net4=Net(:,4);

TNet=[net1 net2]; %Creates the nodes
T2Net=[net3 net4];
NetT=[TNet;T2Net];

%X1Net=unique(TNet,'rows'); %Removes duplicate nodes
%X2Net=unique(T2Net,'rows');
DFNNet=unique(NetT,'rows');

%XY1Net=length(X1Net); %length of the vector=number of individual nodes
%XY2Net=length(X2Net);
XYTOTNet=length(DFNNet)
OriNet=2*length(Net)