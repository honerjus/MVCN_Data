'''This script makes the boxplot'''
clear all
%% Reads output of Part_Final_Time_ok.m
data_20=readmatrix('Quantile_20_norm_s.csv');
Nfinal=(length(data_20));%Number of files to include in final anlysis
data_20=data_20(:,[1:Nfinal]);

quant_20_1=data_20(1,:)./3600;
quant_20_5=data_20(2,:)./3600;
quant_20_16=data_20(3,:)./3600;
quant_20_84=data_20(4,:)./3600;
quant_20_95=data_20(5,:)./3600;
quant_20_99=data_20(6,:)./3600;

donnee=[quant_20_1' quant_20_5' quant_20_95' quant_20_99'];
%writematrix(donnee, 'Quantiles_alpha_22.csv')

%% Plotting
figure, 
set(gcf,'color','w')
%subplot('Position',[0.1 0.1 0.2 0.3])
boxplot([quant_20_5' quant_20_16' quant_20_84' quant_20_95'],'Color',['r'],'notch','on','labels',{'5','16','84','95'},'Symbol', '')% Symbol makes the outliers invisible
set(gca,'yscale','log')
ylim([1e1 2e3]);
xlabel('Quantiles')
ylabel('Normalized Time')
%title('T/d')
box_vars = findall(gca,'Tag','Box');
hLegend = legend(box_vars([3,2,4]), {'Dc=1.6','Dc=1.8','Dc=2.0'},'Location','northwest');
%ylim([0 6e8]);
%yticks(0:1e8:6e8);
title('plot')
