""" This script plots the radial pathways of each of the 10,000 particles """
clear all
Window=250;
all_Part=[];
%% Plotting particle pathways
net=load('Network_Data.0017.txt');
Network_Data = 'Particles_last_location.0017.txt';%.010(alpha=1.4, Dc=2.0) is a good network
data=load(Network_Data);
X_Start=data(:,1);
Y_Start=data(:,2);
X_End=data(:,3);
Y_End=data(:,4);
Final_time=data(:,5);

A = [X_Start(:) X_End(:)]; B = [Y_Start(:) Y_End(:)];
x=[75, 175, 175, 75, 75];%Source release area
y=[240, 240, 248, 248, 240];
hold on
figure,
%subplot('Position',[0.40 0.2 0.2 0.2])
set(gcf,'color','w')
plot(A.',B.','LineWidth', 0.25, 'Color', 'k'), hold on
plot(x, y, 'r-', 'LineWidth', 1);
xticks(0:10:250);
yticks(0:10:250);
xlabel('x[m]')
ylabel('y[m]')
%grid on
axis square
axis([0 Window 0 Window])
l=length(net);
X1=net(1:(l-1),1);
X2=net(1:(l-1),3);
Y1=net(1:(l-1),2);
Y2=net(1:(l-1),4);
A=[X1'; X2']; B=[Y1'; Y2'];
plot(A,B,'LineWidth', 0.25,'Color','k')
hold off
