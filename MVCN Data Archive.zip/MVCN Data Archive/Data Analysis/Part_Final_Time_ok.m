''' This code returns networks with 99% recovery and prepare the input files for Comparative_Plots.m, Boxplots.m '''
clear all
%% Read the DFN_brcv.xx.txt and Particles_last_location.xx.txt files.
all_data=[];
 %num=zeros(1,100);   
 Nfiles=250;%Number of DFN_bcrv.xx.txt in folder
 Nfinal=250;%Number of files to include in final anlysis
 Nrow_brcv=29200;%Number of time steps in DFN_brcv.xx.txt file
 Nrow_part=10000;%Number of time steps in Particles_last_location.xx.txt file
 for ii=1:250
     if ii<=9
         Network_Data = sprintf('DFN_bcrv.000%d.txt',ii);
     elseif ii>9 && ii<100
         Network_Data = sprintf('DFN_bcrv.00%d.txt',ii);
     elseif ii>=100
         Network_Data = sprintf('DFN_bcrv.0%d.txt',ii);
     end
     if isfile(Network_Data);
         data=load(Network_Data);
         all_data = [all_data; data(:,7)];
         num(ii)=ii;
     end
 end

num=nonzeros(num);
alldata=reshape(all_data,[Nrow_brcv,Nfiles]);
Prim_list=alldata;
%Final list of good networks
z=any(alldata);
t=any(alldata~=10000);
p=(alldata(Nrow_brcv,:)>9900);
num_z=num(z);
num_t=num(t);
num_p=num(p);
zt=intersect(num_z,num_t);
Flist=intersect(zt, num_p);
% Removing columns
alldata=alldata(:,any(alldata));% remove column containing only zeros
alldata(:,all(alldata==10000))=[];% remove column containing only 10000
alldata(:,alldata(Nrow_brcv,:)<9900)=[];% remove column where the number of particles obtained is less than 99%

%% Getting time data
Part_Time_data = []; 
Part_X_Start = [];
Part_Y_Start = [];
Part_X_End = [];
Part_Y_End = [];
F_list=Flist';
for k=1:length(F_list)
   index=F_list(k);
   if index<=9
       Part_Data = sprintf('Particles_last_location.000%d.txt',index);
   elseif index>9 && index<100
       Part_Data = sprintf('Particles_last_location.00%d.txt',index);
   elseif index>=100
       Part_Data = sprintf('Particles_last_location.0%d.txt',index);
   end
  % Part_Data = sprintf('Particles_last_location.0%d.txt',index);
   if isfile(Part_Data);
    Part_data=load(Part_Data);
    Part_Time_data = [Part_Time_data; Part_data(:,5)]; 
    Part_X_Start = [Part_X_Start; Part_data(:,1)];
    Part_Y_Start = [Part_Y_Start; Part_data(:,2)];
    Part_X_End = [Part_X_End; Part_data(:,3)];
    Part_Y_End = [Part_Y_End; Part_data(:,4)];  
   end
end

%% Reorganizing Data
Part_Dist = sqrt((Part_X_End-Part_X_Start).^2+(Part_Y_End-Part_Y_Start).^2);% Ecludian distance between particle starting and ending points

%Normalizing Time
Part_Time_Norm=Part_Time_data./Part_Dist;%This is to help compare particle with different pathways
Part_Time_data=reshape(Part_Time_data,[Nrow_part,length(F_list)]);

Time_data=Part_Time_data(:,length(F_list));
writematrix(Time_data, 'TravelTime_20.csv')%Input for the TravelTimePlots script

Part_Time_Norm=reshape(Part_Time_Norm,[10000,length(F_list)]);
%%%
Time_data_norm=Part_Time_Norm(:,length(F_list));
writematrix(Time_data_norm, 'TravelTime_norm_20.csv')%Input for the TravelTimePlots script

Part_Time_data=Part_Time_data(:,length(F_list));

%% Plotting
%%% Quantiles
increment=[0.01 0.05 0.16 0.84 0.95 0.99];
increment_c=[0:0.01:1];
Q1=quantile(Part_Time_Norm,increment);
Q1_c=quantile(Part_Time_Norm,increment_c);

writematrix(Q1_c, 'Quantile_20_norm.csv');% Input file for Comparative_Plots script
writematrix(Q1, 'Quantile_20_norm_s.csv');% Input file for Quantile_values script(Boxplot)
%writematrix(Q3_c, 'Quantile_20_TD.csv');