'''This script is for plotting the breaktrough curves'''
clear all
Nfinal=10;%Number of files to include in final anlysis
%% Reads output of Part_Final_Time_ok.m
data_20=readmatrix('Quantile_20_norm_s.csv');
data_20=data_20(:,[1:Nfinal]);
data_20_c=(readmatrix('Quantile_20_norm.csv'))./3600;
data_20_c=data_20_c(:,[1:Nfinal]);

%Average/Median of the MC simulations
data_20_avg=median(data_20_c,2);

quant_20_1=data_20(1,:)./3600;
quant_20_5=data_20(2,:)./3600;
quant_20_16=data_20(3,:)./3600;
quant_20_84=data_20(4,:)./3600;
quant_20_95=data_20(5,:)./3600;
quant_20_99=data_20(6,:)./3600;

%% Plotting
figure, 
set(gcf,'color','w')
%subplot('Position',[0.1 0.1 0.15 0.25])
increment=[0:0.01:1];
plot(data_20_c(:,[1:Nfinal]),increment','Color',[0.8,0.8,0.8],'LineWidth',1); hold on
set(gca,'xscale','log')
plot(data_20_avg,increment','Color','k','LineWidth',2);
xlim([1e1 1e5]);% For time not normalized
%xlim([1e1 1e6]);% For time/d
%xlim([1e-12 1e-8]);% For time/d
ylim([0 1])
xticks([1,10,100,1000,10000,100000])
ylabel('Quantiles')
xlabel('Normalized Time')
