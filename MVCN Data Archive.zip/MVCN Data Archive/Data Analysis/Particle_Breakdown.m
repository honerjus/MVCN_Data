clear, close all, clc

T=1.2714E-05;
First=1;
Last=250;
TMCrelease=0;
TMCRper=0;
TFlow=0;
Unique_Nodes=0;
TParticleVMC=0;
TParticleVF=0;

for n=First:Last
    if n<=9
        net=load(sprintf('Network_Data.000%d.txt',n));
        particle=load(sprintf('Particles_last_location.000%d.txt',n));
    elseif 9<n&&n<100
        net=load(sprintf('Network_Data.00%d.txt',n));
        particle=load(sprintf('Particles_last_location.00%d.txt',n));
    elseif n>=100
        net=load(sprintf('Network_Data.0%d.txt',n));
        particle=load(sprintf('Particles_last_location.0%d.txt',n));
    end

    pXf=particle(:,3);
    pYf=particle(:,4);

    Final_Particle=[pXf,pYf];
    UFNodes=unique(Final_Particle,"rows");
    UniqueNodes=length(UFNodes);
    Unique_Nodes=Unique_Nodes+UniqueNodes;

    MCnodes=[];
    usedrows=[];

    for i=1:length(UFNodes)
        for j=1:length(net)
            if UFNodes(i,1)==net(j,1) && UFNodes(i,2)==net(j,2) || UFNodes(i,1)==net(j,3) && UFNodes(i,2)==net(j,4)
                if net(j,5)<(T*4.6)
                    nusedrows=net(j,:);
                    usedrows=[usedrows;nusedrows];
                    net(j,:)=[0 0 0 0 0];
                else
                    MCnodes=[MCnodes;UFNodes(i,1) UFNodes(i,2)];
                    net(j,:)=[0 0 0 0 0];
                end
            end
        end
    end

    MCnodeR=unique(MCnodes,'rows');
    MCRelease=length(MCnodeR);
    TMCrelease=TMCrelease+MCRelease;
    MCRper=(MCRelease/UniqueNodes)*100;
    TMCRper=TMCRper+MCRper;

    counter=0;
    MCOut=[];
    for i=1:length(MCnodeR)
        for j=1:length(Final_Particle)
            if MCnodeR(i,1)==particle(j,3) && MCnodeR(i,2)==particle(j,4)
                MCF=particle(j,:);
                MCOut=[MCOut;MCF];
                counter=counter+1;
                particle(j,:)=[0 0 0 0 0];
            else
                counter=counter+0;
            end
        end
    end
    FlowPer=counter/length(Final_Particle)*100;
    TFlow=TFlow+FlowPer;

    FOut=[];
    for i=1:length(particle)
        if particle(i,5)~=0
            F=particle(i,:);
            FOut=[FOut;F];
        end
    end

    ParticleV1=0;
    for i=1:length (MCOut)
        D1=sqrt(((MCOut(i,1)-MCOut(i,3))^2)+((MCOut(i,2)-MCOut(i,4))^2));
        VParticle1=D1/MCOut(i,5);
        ParticleV1=ParticleV1+VParticle1;
    end

    SumParticleV1=ParticleV1/length(MCOut);
    TParticleVMC=SumParticleV1+TParticleVMC;

    ParticleV2=0;
    for i=1:length (FOut)
        D2=sqrt(((FOut(i,1)-FOut(i,3))^2)+((FOut(i,2)-FOut(i,4))^2));
        VParticle2=D2/FOut(i,5);
        ParticleV2=ParticleV2+VParticle2;
    end
    SumParticleV2=ParticleV2/length(FOut);
    TParticleVF=SumParticleV2+TParticleVF;
end

Unique_Output_Nodes=Unique_Nodes/((Last-First)+1)
Mega_Column_Release_Nodes=TMCrelease/((Last-First)+1)
Percentage_of_MC_Node_Release=TMCRper/((Last-First)+1)
Percentace_of_Particles_Release=TFlow/((Last-First)+1)
Particle_Velocity_Mega_Column_Release=TParticleVMC/((Last-First)+1)
Particle_Velocity_Fracture_Release=TParticleVF/((Last-First)+1)