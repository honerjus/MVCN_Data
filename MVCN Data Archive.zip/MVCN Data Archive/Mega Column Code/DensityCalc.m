clear all, clc, close all
L=250; %Domain length of the networks
First=1; %First Network
Last=100; %Last Network
S=8; %Scalar for Mega-Columns
R=2.5; %Radius of normal Columns

for n=First:Last %Identifies Individual Networks
    if n<=9
        net=load(sprintf('Primordial_Network.000%d.txt',n));

    elseif 9<n&&n<100
        net=load(sprintf('Primordial_Network.00%d.txt',n));

    elseif n>=100
        net=load(sprintf('Primordial_Network.0%d.txt',n));
    end
    l=length(net);
    X1=net(1:(l-1),1);
    X2=net(1:(l-1),3);
    Y1=net(1:(l-1),2);
    Y2=net(1:(l-1),4);

    TNet=[X1 Y1]; %Creates the nodes
    T2Net=[X2 Y2];
    NetT=[TNet;T2Net];
    DFNNet=unique(NetT,'rows');
end
EnsFracPer=Ensamble/((Last-First)+1)