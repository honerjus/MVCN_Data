close all, clear, clc
First=1;
Last=250;

for n=First:Last %Identifies Individual Networks
    if n<=9        
        net=load(sprintf('Primordial_Network.000%d.txt',n));
    elseif 9<n&n<100
        net=load(sprintf('Primordial_Network.00%d.txt',n));
    elseif n>=100
        net=load(sprintf('Primordial_Network.0%d.txt',n));
    end
    
    if n<=9
        writematrix(net,sprintf('Network_Data.000%d.txt',n),'Delimiter','tab');
    elseif 9<n&n<100
        writematrix(net,sprintf('Network_Data.00%d.txt',n),'Delimiter','tab');
    elseif n>=100
        writematrix(net,sprintf('Network_Data.0%d.txt',n),'Delimiter','tab');
    end
end