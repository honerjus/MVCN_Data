clear all, clc, close all

L=250; %Domain length of the networks
First=103; %First Network
Last=250; %Last Network
S=8; %Scalar for Mega-Columns
R=2.5; %Radius of normal Columns
T=64; %Transmissivity scalar

Ensamble=0;
Pensamble=0;

for n=First:Last %Identifies Individual Networks
    if n<=9
        net=load(sprintf('Network_Data.000%d.txt',n));

    elseif 9<n&&n<100
        net=load(sprintf('Network_Data.00%d.txt',n));

    elseif n>=100
        net=load(sprintf('Network_Data.0%d.txt',n));
    end
    n

    %Seperates Matrix into usable values
    l=length(net);
    X1=net(1:(l-1),1);
    X2=net(1:(l-1),3);
    Y1=net(1:(l-1),2);
    Y2=net(1:(l-1),4);

    TNet=[X1 Y1]; %Creates the nodes
    T2Net=[X2 Y2];
    NetT=[TNet;T2Net];
    DFNNet=unique(NetT,'rows');

    Fracture2=0;

    for w=1:(l-1) %Determines Fracture Density of network and saves variable
        fracturel=sqrt((X1(w,1)-X2(w,1))^2+(Y1(w,1)-Y2(w,1))^2);
        Fracture2=Fracture2+fracturel;
    end
    FracturePer=(Fracture2/250)*100;
    Ensamble=FracturePer+Ensamble;

    maxNumIterationsx=ceil(L/((S*R*2)))+2;
    maxNumIterationsy=ceil(L/((S*R*sqrt(3))))+1; %max length / width, rounding up is max iterations
    grid=zeros(maxNumIterationsx, maxNumIterationsy, 2); %initialize grid for x,y values of each point

    for i=1:maxNumIterationsx+1
        for j=1:maxNumIterationsy+1

            if (mod(j,2)==1)%odd
                x=(i-1)*(S*R)*2-((S*R)*3/4)-(S*R) + rem(L,(S*R)); % if j is odd, we have additional space
            else
                x=(i-1)*(S*R)*2+((S*R)*1/4)-(S*R) + rem(L,(S*R)); % if j is even, start at point 0
            end

            y=(j-1)*(S*R)*sqrt(3)-(S*R)*sqrt(3)/2-(S*R)*sqrt(3)/2 + rem(L,(S*R)*sqrt(3))/2; % uniform step, starting at y = 0

            if (x < L + 2*(S*R)*(sqrt(3)/2+(.1)))
                grid(i,j,1)=x;
                grid(i,j,2)=y;
            end
        end
    end
    close all

    gridx = nonzeros(grid(:,:,1));
    gridy = nonzeros(grid(:,:,2));

    gridNodes(:,1) = gridx;
    gridNodes(:,2) = gridy;

    %figure,plot(gridx,gridy,'.') %Turn on to show the grid

    % get interior node count
    numInteriorNodes = 0;
    for i=1:length(gridNodes)
        x1=gridNodes(i,1);
        y1=gridNodes(i,2);
        if x1 > 0 && x1 < L && y1 > 0 && y1 < L
            numInteriorNodes = numInteriorNodes + 1;
        end
    end

    %Now, find nearest points on fracture network to static grid points
    targetPts=zeros(numInteriorNodes, 2); %initialize grid for x,y values of each point

    interiorNodeIter = 1;
    for i=1:length(gridNodes)
        x1=gridNodes(i,1);
        y1=gridNodes(i,2);

        if x1 > 0 && x1 < L && y1 > 0 && y1 < L

            Xclosest=0;
            Yclosest=0;
            largestCurrentDist=L;

            for k=1:length(DFNNet)
                x2=DFNNet(k,1);
                y2=DFNNet(k,2);

                x=x1-x2;
                y=y1-y2;
                dist=sqrt(x^2+y^2);

                if dist<largestCurrentDist
                    largestCurrentDist=dist;
                    Xclosest=x2;
                    Yclosest=y2;
                end
            end

            targetPts(interiorNodeIter,1)=Xclosest;
            targetPts(interiorNodeIter,2)=Yclosest;

            gridNodes(i,1) = Xclosest;
            gridNodes(i,2) = Yclosest;

            interiorNodeIter = interiorNodeIter + 1;
        end

    end

    %     % gather together all nodes (on and off grid)
    %     for i=1:length(gridNodes)
    %         x1=gridNodes(i,1);
    %         y1=gridNodes(i,2);
    %         if x1 > 0 && x1 < L && y1 > 0 && y1 < L
    %             gridNodes(i,1) = targetPts(i,1);
    %             gridNodes(i,2) = targetPts(i,2);
    %         end
    %     end

    %     figure(1)
    plot(gridNodes(:,1),gridNodes(:,2),'*','color','r')
    hold on
    A=[X1'; X2']; B=[Y1'; Y2'];
    plot(A,B,'LineWidth', 0.75,'Color','k')
    %     hold off

    megaColumnNodeCtr = 0;
    C=(55/100);
    %get center point
    for i = 1:length(gridNodes)
        for bool = 1:2 %handle top and bottom nodes
            xmin = gridNodes(i,1)-(S*R)*C;
            xmax = gridNodes(i,1)+(S*R)*2+(S*R)*C;
            if bool == 1
                ymin = gridNodes(i,2)-(S*R)*C;
                ymax = gridNodes(i,2)+(S*R)*2+(S*R)*C;
            else
                ymin = gridNodes(i,2)-(S*R)*2-(S*R)*C;
                ymax = gridNodes(i,2)+(S*R)*C;
            end

%                         plot(xmin, ymin,'*','color','b');
%                         plot(xmin, ymax,'*','color','b');
%                         plot(xmax, ymin,'*','color','b');
%                         plot(xmax, ymax,'*','color','b');

            threeNodes = zeros(3,2);
            iter = 1;
            for j = 1:length(gridNodes)
                if gridNodes(j,1) > xmin && gridNodes(j,1) < xmax && gridNodes(j,2) > ymin && gridNodes(j,2) < ymax
                    threeNodes(iter,1) = gridNodes(j,1);
                    threeNodes(iter,2) = gridNodes(j,2);
                    iter = iter + 1;
                end
            end
            iter = iter - 1; % account for over counting

            % if 3 nodes, get center point
            if iter == 3
                xavg = (threeNodes(1,1) + threeNodes(2,1) + threeNodes(3,1))/3;
                yavg = (threeNodes(1,2) + threeNodes(2,2) + threeNodes(3,2))/3;

                %search and find nearest point
                Xclosest=0;
                Yclosest=0;
                largestCurrentDist=L;

                for k=1:length(DFNNet)
                    x2=DFNNet(k,1);
                    y2=DFNNet(k,2);

                    x=xavg-x2;
                    y=yavg-y2;
                    dist=sqrt(x^2+y^2);

                    if dist<largestCurrentDist
                        largestCurrentDist=dist;
                        Xclosest=x2;
                        Yclosest=y2;
                    end
                end

                if xavg > 0 && xavg < 249.5 && yavg > 0 && yavg < 249.5 % only save if not on edge

                    megaColumnNodeCtr = megaColumnNodeCtr + 1;
                    megaColumnNodes(megaColumnNodeCtr,1) = Xclosest;
                    megaColumnNodes(megaColumnNodeCtr,2) = Yclosest;

                    plot(Xclosest,Yclosest,'*','color','g')

                else
                    megaColumnNodeCtr = megaColumnNodeCtr + 1;
                    megaColumnNodes(megaColumnNodeCtr,1) = xavg;
                    megaColumnNodes(megaColumnNodeCtr,2) = yavg;

                    plot(xavg,yavg,'*','color','g')
                end

%                 plot(Xclosest,Yclosest,'*','color','g')
            end
        end
    end

    megaColumns = [];
    megaColumnsCtr = 0;

    % left-right/top-down connections start below:
    currentNode(1,1) = megaColumnNodes(1,1);
    currentNode(1,2) = megaColumnNodes(1,2);

    unconnectedNodes = zeros(1,2);
    unconnectedNodeCtr = 1;

    for o = 1:2
        for i = 1:length(megaColumnNodes)

            if (o==1)
                xmin = megaColumnNodes(i,1);
                xmax = megaColumnNodes(i,1)+(S*R)*(4/3)+(5*S)/10;
                ymin = megaColumnNodes(i,2)-(0.4147*(S*R)+S*2);
                ymax = megaColumnNodes(i,2)+(0.4147*(S*R)+S*2);
            elseif (o==2)
                xmin = megaColumnNodes(i,1)-(S*R)/2;
                xmax = megaColumnNodes(i,1)+(S*R)/2;
                ymin = megaColumnNodes(i,2);
                ymax = megaColumnNodes(i,2)+((1.1547*(S*R))+S*1.5);
            end

%                         plot(xmin, ymin,'*','color','b');
%                         plot(xmin, ymax,'*','color','b');
%                         plot(xmax, ymin,'*','color','b');
%                         plot(xmax, ymax,'*','color','b');

            doContinue = false;
            for j = 1:length(megaColumnNodes)
                if megaColumnNodes(j,1) > xmin && megaColumnNodes(j,1) < xmax && megaColumnNodes(j,2) > ymin && megaColumnNodes(j,2) < ymax
                    doContinue = true;
                end
            end

            OBnode = false;
            if megaColumnNodes(i,1) < 0 || megaColumnNodes(i,1) > L || megaColumnNodes(i,2) < 0 || megaColumnNodes(i,2) > L
%                 doContinue = false;
                OBnode = true;
                targetNode(1,1) = megaColumnNodes(i,1);
                targetNode(1,2) = megaColumnNodes(i,2);
            end


            tnnodes = zeros(1,2);
            tnnodesCtr = 1;
            for j = 1:length(megaColumnNodes)
                if ~OBnode
                    if megaColumnNodes(j,1) > xmin && megaColumnNodes(j,1) < xmax && megaColumnNodes(j,2) > ymin && megaColumnNodes(j,2) < ymax
%                         targetNode(1,1) = megaColumnNodes(j,1);
%                         targetNode(1,2) = megaColumnNodes(j,2);
                        tnnodes(tnnodesCtr,1) = megaColumnNodes(j,1);
                        tnnodes(tnnodesCtr,2) = megaColumnNodes(j,2);
                        tnnodesCtr = tnnodesCtr + 1;
                    end
                else
                    if megaColumnNodes(j,1) > xmin && megaColumnNodes(j,1) < xmax && megaColumnNodes(j,2) > ymin && megaColumnNodes(j,2) < ymax
                        megaColumnNodesTemp(1,1) = megaColumnNodes(j,1);
                        megaColumnNodesTemp(1,2) = megaColumnNodes(j,2);
                    end
                end
            end

            if (size(tnnodes,1) > 1)
                if (o==1)

                % attempt 3
%                 idealNode(1,1) = megaColumnNodes(i,1) + S*R;
%                 idealNode(1,2) = megaColumnNodes(i,2);
% 
%                 %search and find nearest point
%                 XclosestTT=0;
%                 YclosestTT=0;
%                 largestCurrentDistTT=L;
% 
%                 for ii=1:size(tnnodes,1)
%                     x2TT=tnnodes(ii,1);
%                     y2TT=tnnodes(ii,2);
% 
%                     x=idealNode(1,1)-x2TT;
%                     y=idealNode(1,2)-y2TT;
%                     distTT=sqrt(x^2+y^2);
% 
%                     if dist<largestCurrentDistTT
%                         largestCurrentDistTT=distTT;
%                         XclosestTT=x2TT;
%                         YclosestTT=y2TT;
%                     end
%                 end
%                 targetNode(1,1) = XclosestTT;
%                 targetNode(1,2) = YclosestTT;


                    % attempt 2
                    maxS = 0;
                    maxIn = -1;
                    for ii = 1:size(tnnodes,1)
                        if tnnodes(ii,1) > maxS
                            maxS = tnnodes(ii,1);
                            maxIn = ii;
                        end
                    end
                    targetNode(1,1) = tnnodes(maxIn,1);
                    targetNode(1,2) = tnnodes(maxIn,2);

                    % attempt 1
%                     if tnnodes(1,1) > tnnodes(2,1)
%                         targetNode(1,1) = tnnodes(1,1);
%                         targetNode(1,2) = tnnodes(1,2);
%                     else
%                         targetNode(1,1) = tnnodes(2,1);
%                         targetNode(1,2) = tnnodes(2,2);
%                     end
                elseif (o==2)

                    % attempt 3
%                     idealNode(1,1) = megaColumnNodes(i,1);
%                     idealNode(1,2) = megaColumnNodes(i,2) + sqrt(3)/3*S*R;
% 
%                     %search and find nearest point
%                     XclosestTT=0;
%                     YclosestTT=0;
%                     largestCurrentDistTT=L;
% 
%                     for ii=1:size(tnnodes,1)
%                         x2TT=tnnodes(ii,1);
%                         y2TT=tnnodes(ii,2);
% 
%                         x=idealNode(1,1)-x2TT;
%                         y=idealNode(1,2)-y2TT;
%                         distTT=sqrt(x^2+y^2);
% 
%                         if dist<largestCurrentDistTT
%                             largestCurrentDistTT=distTT;
%                             XclosestTT=x2TT;
%                             YclosestTT=y2TT;
%                         end
%                     end
%                     targetNode(1,1) = XclosestTT;
%                     targetNode(1,2) = YclosestTT;

                    % attempt 2
                    maxS = 0;
                    maxIn = -1;
                    for ii = 1:size(tnnodes,1)
                        if tnnodes(ii,2) > maxS
                            maxS = tnnodes(ii,2);
                            maxIn = ii;
                        end
                    end
                    targetNode(1,1) = tnnodes(maxIn,1);
                    targetNode(1,2) = tnnodes(maxIn,2);

                    % attempt 1
%                     if tnnodes(1,2) > tnnodes(2,2)
%                         targetNode(1,1) = tnnodes(1,1);
%                         targetNode(1,2) = tnnodes(1,2);
%                     else
%                         targetNode(1,1) = tnnodes(2,1);
%                         targetNode(1,2) = tnnodes(2,2);
%                     end
                end
            else
                if ~OBnode
                    targetNode(1,1) = tnnodes(1,1);
                    targetNode(1,2) = tnnodes(1,2);
                end
            end

            if OBnode
                if megaColumnNodesTemp(1,1) < 0 || megaColumnNodesTemp(1,1) > L || megaColumnNodesTemp(1,2) < 0 || megaColumnNodesTemp(1,2) > L
                    doContinue = false;
                end
            end

            if ~doContinue
                continue;
            end

            plot(targetNode(1,1), targetNode(1,2),'*','color','y');

            % connect the dots between megaColumnNodes

            connected = false;
            edgeBoundry = false;
            firstRun = true;

            usedNodes = [];
            usedNodesCtr = 0;

            while ~connected
                % find fractures that connect to the node

                if firstRun
                    if ~OBnode
                        currentNode(1,1) = megaColumnNodes(i,1);
                        currentNode(1,2) = megaColumnNodes(i,2);
                    else
                        currentNode(1,1) = megaColumnNodesTemp(1,1);
                        currentNode(1,2) = megaColumnNodesTemp(1,2);
                    end
                end

                fractures = [];
                endPoints = [];
                numFractures = 1;
                for k = 1:length(net)
                    if net(k,1) == currentNode(1,1) && net(k,2) == currentNode(1,2)
                        fractures(numFractures,:,:,:,:,:) = net(k,:,:,:,:,:);
                        endPoints(numFractures,1) = net(k,3);
                        endPoints(numFractures,2) = net(k,4);
                        endPoints(numFractures,3) = net(k,5);
                        numFractures = numFractures + 1;
                    elseif net(k,3) == currentNode(1,1) && net(k,4) == currentNode(1,2)
                        fractures(numFractures,:,:,:,:,:) = net(k,:,:,:,:,:);
                        endPoints(numFractures,1) = net(k,1);
                        endPoints(numFractures,2) = net(k,2);
                        endPoints(numFractures,3) = net(k,5);
                        numFractures = numFractures + 1;
                    end
                end
                numFractures = numFractures - 1; %subtract one to acccount for over counting

                %             for p = 1:numFractures
                %                 plot(endPoints(p,1), endPoints(p,2),'*','color','m');
                %             end

                Xclosest=0;
                Yclosest=0;
                Transmissivity = 0;
                largestCurrentDist=L;

                for f = 1:numFractures
                    x = targetNode(1,1) - endPoints(f,1);
                    y = targetNode(1,2) - endPoints(f,2);

                    dist = sqrt(x^2+y^2);

                    if dist<largestCurrentDist
                        % check if used before
                        used = false;
                        for u = 1:size(usedNodes,1)
                            if (usedNodes(u,1) == endPoints(f,1) && usedNodes(u,2) == endPoints(f,2))
                                used = true;
                            end
                        end

                        %check if edge node
                        if numFractures<3 && ~firstRun
                            connected=true;
                            continue;
                        end

                        if ~used
                            prevdist=dist;
                            largestCurrentDist=dist;
                            Xclosest=endPoints(f,1);
                            Yclosest=endPoints(f,2);
                            Transmissivity = endPoints(f,3);
                        end
                    end
                end

                % continue if edge met
                if connected
                    continue;
                end

                megaColumns(megaColumnsCtr+1, 1) = currentNode(1,1);
                megaColumns(megaColumnsCtr+1, 2) = currentNode(1,2);
                megaColumns(megaColumnsCtr+1, 3) = Xclosest;
                megaColumns(megaColumnsCtr+1, 4) = Yclosest;
                megaColumns(megaColumnsCtr+1, 5) = Transmissivity*T;

                megaColumnsCtr = megaColumnsCtr + 1;

                usedNodes(usedNodesCtr + 1,1) = currentNode(1,1);
                usedNodes(usedNodesCtr + 1,2) = currentNode(1,2);

                usedNodesCtr = usedNodesCtr + 1;

                currentNode(1,1) = Xclosest;
                currentNode(1,2) = Yclosest;

                if Xclosest == targetNode(1,1) && Yclosest == targetNode(1,2)
                    connected = true;
                end

                if (Yclosest == L || Xclosest == L || Yclosest == 0 || Xclosest == 0) && ~connected
                    connected = true;
                    edgeBoundry = true;
                end

                A=[megaColumns(megaColumnsCtr, 1); megaColumns(megaColumnsCtr, 3)]; B=[megaColumns(megaColumnsCtr, 2); megaColumns(megaColumnsCtr, 4)];
                plot(A,B,'LineWidth', 1,'Color','c')

                firstRun = false;

            end

            % TODO remove if un-necessary
            if targetNode(1,1) ~= currentNode(1,1) && targetNode(1,2) ~= currentNode(1,2) && ~edgeBoundry
                % save unconnected nodes:
                % save targetNode and currentNode
                unconnectedNodes(unconnectedNodeCtr,:) = [megaColumnNodes(i,1), megaColumnNodes(i,2)];
                unconnectedNodeCtr = unconnectedNodeCtr + 1;
            end

            %disp("done w one;");
        end
    end

    if n<=9
        writematrix(megaColumns,sprintf('Primordial_Network.000%d.txt',n),'Delimiter','tab');
        Pnet=load(sprintf('Primordial_Network.000%d.txt',n));
    elseif 9<n&n<100
        writematrix(megaColumns,sprintf('Primordial_Network.00%d.txt',n),'Delimiter','tab');
        Pnet=load(sprintf('Primordial_Network.00%d.txt',n));
    elseif n>=100
        writematrix(megaColumns,sprintf('Primordial_Network.0%d.txt',n),'Delimiter','tab');
        Pnet=load(sprintf('Primordial_Network.0%d.txt',n));
    end

    pl=length(Pnet);
    pX1=Pnet(:,1);
    pX2=Pnet(:,3);
    pY1=Pnet(:,2);
    pY2=Pnet(:,4);
    Fracture4=0;
    l=length(Pnet);

    for w=1:(l-1) %Determines Fracture Density of network and saves variable
        fracture3=sqrt((pX1(w,1)-pX2(w,1))^2+(pY1(w,1)-pY2(w,1))^2);
        Fracture4=Fracture4+fracture3;
    end

    PFracturePer=(Fracture4/250)*100
    Pensamble=PFracturePer+Pensamble;
            close all

    for a=1:length(megaColumns)
        for b=1:length(net)
            if megaColumns(a,1) == net(b,1) && megaColumns(a,2) == net(b,2) && megaColumns(a,3) == net(b,3) && megaColumns(a,4) == net(b,4)
                net(b,5)=net(b,5)*T;
            elseif megaColumns(a,1) == net(b,3) && megaColumns(a,2) == net(b,4) && megaColumns(a,3) == net(b,1) && megaColumns(a,4) == net(b,2)
                net(b,5)=net(b,5)*T;
            end
        end
    end

    if n<=9
        writematrix(net,sprintf('Network_Data.000%d.txt',n),'Delimiter','tab');
    elseif 9<n&n<100
        writematrix(net,sprintf('Network_Data.00%d.txt',n),'Delimiter','tab');
    elseif n>=100
        writematrix(net,sprintf('Network_Data.0%d.txt',n),'Delimiter','tab');
    end
end
EnsFracPer=Ensamble/((Last-First)+1) %Calculates the average fracture density of all the networks
EstFracPer=(1.0428*(S^(-0.835)))*EnsFracPer
PEnsFracPer=Pensamble/((Last-First)+1)

% % plot to check
% figure(2)
% % plot(net(:,1),net(:,2),'*','color','k')
% l=length(net);
% X1=net(1:(l-1),1);
% X2=net(1:(l-1),3);
% Y1=net(1:(l-1),2);
% Y2=net(1:(l-1),4);
% A=[X1'; X2']; B=[Y1'; Y2'];
% hold on
% plot(A,B,'LineWidth', 0.75,'Color','k')
% pl=length(Pnet);
% pX1=Pnet(:,1);
% pX2=Pnet(:,3);
% pY1=Pnet(:,2);
% pY2=Pnet(:,4);
% Fracture4=0;
% l=length(Pnet);
% C=[pX1'; pX2']; D=[pY1'; pY2'];
% plot(C,D,'LineWidth', 2,'Color','k')
% axis equal
% hold off